# coordinator/views.py
import json
import os
import subprocess
import calendar
from datetime import datetime, timedelta
from decimal import Decimal
from venv import logger

from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.core.paginator import Paginator
from django.db import transaction, IntegrityError
from django.db.models import ProtectedError, Count, Q, Exists, OuterRef, Sum, Avg, Max
from django.http import JsonResponse, HttpResponse, FileResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST, require_GET, require_http_methods

# ===== IMPORTACIÓN DEL DECORADOR UNIFICADO =====
from core.decorators import role_required

from booking.models import (
    Assistant, Bus, BusDocument, City, Company, Driver, DriverDocument,
    Maintenance, Route, Seat, SeatHold, Terminal, Ticket, Trip, Agency,
    Parcel, FuelRecord, BusLayout, AuditLog, User
)
from booking.forms import (
    TerminalForm, CityForm, RouteForm, RouteStopFormSet,
    AssistantForm, DriverForm, AgencyForm, BusFullForm, TripForm
)


# ============================================================================
# ALIAS PARA SIMPLIFICAR DECORADORES
# ============================================================================
coordinator_required = role_required(['admin', 'coordinator'])
admin_only = role_required(['admin'])
security_auditor_only = role_required(['admin', 'coordinator'])


# ============================================================================
# HELPERS UTILITARIOS
# ============================================================================

def assign_missing_numbers(numbers, layout, prefix, start_from=1):
    """
    Asigna números correlativos a las celdas tipo 'L' que no tengan número.
    Retorna (numbers_actualizados, último_contador_usado).
    """
    counter = start_from
    for i in range(len(numbers)):
        if layout[i] == 'L' and (i >= len(numbers) or not numbers[i]):
            numbers[i] = f"{prefix}{counter}"
            counter += 1
    return numbers, counter


def make_aware_datetime(dt_str, field_name="Fecha"):
    """
    Convierte string de datetime-local a datetime timezone-aware.
    Lanza ValidationError si el formato es inválido.
    """
    if not dt_str:
        return None
    try:
        # Intentar parsear con zona horaria primero
        try:
            from dateutil import parser
            dt = parser.parse(dt_str)
            if dt.tzinfo is None:
                return timezone.make_aware(dt)
            return dt
        except:
            # Fallback a formato estándar
            naive = datetime.strptime(dt_str, '%Y-%m-%dT%H:%M')
            return timezone.make_aware(naive)
    except (ValueError, TypeError) as e:
        raise ValidationError(f"{field_name}: formato inválido. Use YYYY-MM-DDTHH:MM. Error: {e}")


def validate_trip_conflicts(route, bus, driver1_id, driver2_id, departure_dt, arrival_dt, exclude_trip=None):
    """
    Valida que no haya conflictos con otros viajes.
    Retorna lista de errores.
    """
    errors = []
    
    # Validar que la ruta sea válida (origen != destino)
    if route.origin == route.destination:
        errors.append("El origen y destino de la ruta no pueden ser iguales.")
    
    # Validar que el bus no tenga otro viaje en el mismo horario
    bus_conflicts = Trip.objects.filter(
        bus=bus,
        departure__lt=arrival_dt,
        arrival__gt=departure_dt
    )
    if exclude_trip:
        bus_conflicts = bus_conflicts.exclude(pk=exclude_trip.pk)
    if bus_conflicts.exists():
        errors.append(f"El bus {bus.plate} ya tiene un viaje programado en ese horario.")
    
    # Validar que el chofer principal no tenga otro viaje
    if driver1_id:
        driver1_conflicts = Trip.objects.filter(
            driver1_id=driver1_id,
            departure__lt=arrival_dt,
            arrival__gt=departure_dt
        )
        if exclude_trip:
            driver1_conflicts = driver1_conflicts.exclude(pk=exclude_trip.pk)
        if driver1_conflicts.exists():
            errors.append("El chofer principal ya tiene un viaje programado en ese horario.")
    
    # Validar que el chofer secundario no tenga otro viaje
    if driver2_id:
        driver2_conflicts = Trip.objects.filter(
            driver2_id=driver2_id,
            departure__lt=arrival_dt,
            arrival__gt=departure_dt
        )
        if exclude_trip:
            driver2_conflicts = driver2_conflicts.exclude(pk=exclude_trip.pk)
        if driver2_conflicts.exists():
            errors.append("El chofer secundario ya tiene un viaje programado en ese horario.")
    
    return errors


def get_backup_dir():
    """Retorna la ruta del directorio de respaldos."""
    backup_dir = os.path.join(settings.BASE_DIR, 'backups')
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)
    return backup_dir


def create_backup():
    """Crea un respaldo de la base de datos PostgreSQL."""
    backup_dir = get_backup_dir()
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_file = os.path.join(backup_dir, f'backup_{timestamp}.sql')
    
    db_settings = settings.DATABASES['default']
    host = db_settings.get('HOST', 'localhost')
    port = db_settings.get('PORT', '5432')
    name = db_settings['NAME']
    user = db_settings['USER']
    password = db_settings['PASSWORD']
    
    env = os.environ.copy()
    env['PGPASSWORD'] = password
    
    cmd = [
        'pg_dump',
        '-h', host,
        '-p', str(port),
        '-U', user,
        '-d', name,
        '-f', backup_file,
        '--clean',
        '--if-exists'
    ]
    
    try:
        result = subprocess.run(cmd, env=env, capture_output=True, text=True, check=True)
        return backup_file
    except subprocess.CalledProcessError as e:
        print(f"Error en pg_dump: {e.stderr}")
        return None
    except Exception as e:
        print(f"Error inesperado: {e}")
        return None


# ============================================================================
# DASHBOARD DEL COORDINADOR
# ============================================================================

@login_required
@coordinator_required
def dashboard(request):
    """
    Panel principal del coordinador con métricas, próximos viajes
    y alertas operacionales.
    """
    # Limpiar mensajes antiguos de la sesión
    storage = messages.get_messages(request)
    storage.used = True
    list(storage)

    now = timezone.now()
    today = now.date()

    # ============================================================
    # MÉTRICAS DE RESUMEN
    # ============================================================
    viajes_hoy_qs = Trip.objects.filter(departure__date=today)
    viajes_hoy = viajes_hoy_qs.count()

    proxima_semana = today + timedelta(days=7)
    buses_activos = Trip.objects.filter(
        departure__date__range=[today, proxima_semana]
    ).values('bus').distinct().count()

    pasajeros_hoy = Ticket.objects.filter(
        trip__departure__date=today
    ).count()

    trips_hoy = viajes_hoy_qs.select_related(
        'route__origin',
        'route__destination',
        'bus',
        'driver1',
    ).annotate(
        sold_count=Count('tickets')
    )

    ocupacion_promedio = 0
    if trips_hoy.exists():
        total_ocupacion = sum(
            (
                trip.sold_count / trip.seats_total * 100
                if trip.seats_total else 0
            )
            for trip in trips_hoy
        )
        ocupacion_promedio = round(
            total_ocupacion / trips_hoy.count(),
            1,
        )

    # ============================================================
    # VIAJES PRÓXIMOS - 24 HORAS
    # ============================================================
    proximas_24h = now + timedelta(hours=24)

    viajes_proximos_qs = Trip.objects.filter(
        departure__gte=now,
        departure__lte=proximas_24h,
    ).select_related(
        'route__origin',
        'route__destination',
        'bus',
        'driver1',
    ).annotate(
        sold_count=Count('tickets')
    ).order_by('departure')

    viajes_data = []

    for trip in viajes_proximos_qs:
        libres = max(
            (trip.seats_total or 0) - trip.sold_count,
            0,
        )

        estado = (
            "Próximo"
            if trip.departure > now
            else "En curso"
        )

        viajes_data.append({
            'id': trip.id,
            'hora': timezone.localtime(
                trip.departure
            ).strftime('%H:%M'),
            'ruta': (
                f"{trip.route.origin.name} "
                f"→ {trip.route.destination.name}"
            ),
            'bus': trip.bus.plate,
            'chofer': (
                trip.driver1.full_name
                if trip.driver1
                else "Sin asignar"
            ),
            'asientos_totales': trip.seats_total,
            'asientos_libres': libres,
            'asientos_ocupados': trip.sold_count,
            'estado': estado,
            'estado_color': (
                'success'
                if estado == 'Próximo'
                else 'warning'
            ),
        })

    # ============================================================
    # ALERTAS OPERACIONALES
    # ============================================================
    alertas_operacionales = []
    limite_30_dias = today + timedelta(days=30)

    # Documentos vencidos
    driver_docs_vencidos = DriverDocument.objects.filter(
        expiry_date__isnull=False,
        expiry_date__lt=today,
    ).count()

    bus_docs_vencidos = BusDocument.objects.filter(
        expiry_date__isnull=False,
        expiry_date__lt=today,
    ).count()

    total_docs_vencidos = (
        driver_docs_vencidos
        + bus_docs_vencidos
    )

    if total_docs_vencidos:
        alertas_operacionales.append({
            'level': 'danger',
            'icon': 'fa-file-circle-xmark',
            'title': 'Documentación vencida',
            'message': (
                f'{total_docs_vencidos} documento(s) '
                'de personal o flota están vencidos.'
            ),
            'url_name': 'coordinator:expiring_documents',
            'action': 'Revisar documentos',
        })

    # Documentos próximos a vencer
    driver_docs_proximos = DriverDocument.objects.filter(
        expiry_date__isnull=False,
        expiry_date__gte=today,
        expiry_date__lte=limite_30_dias,
    ).count()

    bus_docs_proximos = BusDocument.objects.filter(
        expiry_date__isnull=False,
        expiry_date__gte=today,
        expiry_date__lte=limite_30_dias,
    ).count()

    total_docs_proximos = (
        driver_docs_proximos
        + bus_docs_proximos
    )

    if total_docs_proximos:
        alertas_operacionales.append({
            'level': 'warning',
            'icon': 'fa-file-circle-exclamation',
            'title': 'Documentos por vencer',
            'message': (
                f'{total_docs_proximos} documento(s) '
                'vencen durante los próximos 30 días.'
            ),
            'url_name': 'coordinator:expiring_documents',
            'action': 'Ver vencimientos',
        })

    # Mantenciones por kilometraje.
    # El modelo Maintenance usa next_maintenance_km y el Bus mantiene
    # current_mileage / next_maintenance_mileage. Para el dashboard
    # usamos los datos operacionales del Bus, evitando consultar
    # un campo de fecha que no existe en Maintenance.
    buses_mantenimiento = Bus.objects.filter(
        is_active=True,
        next_maintenance_mileage__gt=0,
    ).only(
        'id',
        'plate',
        'current_mileage',
        'next_maintenance_mileage',
    )

    mantenciones_vencidas = 0
    mantenciones_proximas = 0
    margen_mantenimiento_km = 1000

    for bus_item in buses_mantenimiento:
        km_actual = bus_item.current_mileage or 0
        km_proximo = bus_item.next_maintenance_mileage or 0
        km_restantes = km_proximo - km_actual

        if km_restantes <= 0:
            mantenciones_vencidas += 1
        elif km_restantes <= margen_mantenimiento_km:
            mantenciones_proximas += 1

    if mantenciones_vencidas:
        alertas_operacionales.append({
            'level': 'danger',
            'icon': 'fa-screwdriver-wrench',
            'title': 'Mantenciones vencidas',
            'message': (
                f'{mantenciones_vencidas} bus(es) ya alcanzaron '
                'el kilometraje programado para mantenimiento.'
            ),
            'url_name': 'coordinator:maintenance_list',
            'action': 'Revisar mantenciones',
        })

    if mantenciones_proximas:
        alertas_operacionales.append({
            'level': 'warning',
            'icon': 'fa-screwdriver-wrench',
            'title': 'Mantenciones próximas',
            'message': (
                f'{mantenciones_proximas} bus(es) están a menos de '
                f'{margen_mantenimiento_km} km de su próximo mantenimiento.'
            ),
            'url_name': 'coordinator:maintenance_list',
            'action': 'Revisar mantenciones',
        })

    # Viajes próximos sin chofer principal
    viajes_sin_chofer = Trip.objects.filter(
        departure__gte=now,
        departure__lte=now + timedelta(days=7),
        driver1__isnull=True,
    ).count()

    if viajes_sin_chofer:
        alertas_operacionales.append({
            'level': 'danger',
            'icon': 'fa-user-slash',
            'title': 'Viajes sin chofer',
            'message': (
                f'{viajes_sin_chofer} viaje(s) de los próximos '
                '7 días no tienen chofer principal asignado.'
            ),
            'url_name': 'coordinator:trips_dashboard',
            'action': 'Asignar chofer',
        })

    context = {
        'title': 'Dashboard - Coordinador',
        'viajes_hoy': viajes_hoy,
        'buses_activos': buses_activos,
        'pasajeros_hoy': pasajeros_hoy,
        'ocupacion_promedio': ocupacion_promedio,
        'viajes_proximos': viajes_data,
        'alertas_operacionales': alertas_operacionales,
        'total_alertas': len(alertas_operacionales),
    }

    return render(
        request,
        'coordinator/dashboard.html',
        context,
    )

# ============================================================================
# VISTAS DE BUSES
# ============================================================================

@login_required
@coordinator_required
def bus_list(request):
    """
    Centro operacional de buses.

    Muestra capacidad física real, actividad, historial y accesos directos
    a datos, plano, documentos, mantenimiento y combustible.
    """
    now = timezone.now()
    today = timezone.localdate()

    query = request.GET.get('q', '').strip()
    status_filter = request.GET.get('status', 'all')

    buses_qs = (
        Bus.objects
        .select_related('company')
        .annotate(
            real_seat_count=Count('seats', distinct=True),
            trip_count=Count('trips', distinct=True),
            future_trip_count=Count(
                'trips',
                filter=Q(trips__departure__gt=now),
                distinct=True,
            ),
            ticket_count=Count('trips__tickets', distinct=True),
            document_count=Count('documents', distinct=True),
            maintenance_count=Count('maintenances', distinct=True),
            fuel_record_count=Count('fuel_records', distinct=True),
        )
        .order_by('-is_active', 'company__name', 'plate')
    )

    if query:
        buses_qs = buses_qs.filter(
            Q(plate__icontains=query)
            | Q(model__icontains=query)
            | Q(brand__icontains=query)
            | Q(company__name__icontains=query)
        )

    if status_filter == 'active':
        buses_qs = buses_qs.filter(is_active=True)
    elif status_filter == 'inactive':
        buses_qs = buses_qs.filter(is_active=False)

    buses = list(buses_qs)

    for bus in buses:
        bus.has_history = bool(
            bus.trip_count
            or bus.ticket_count
            or bus.document_count
            or bus.maintenance_count
            or bus.fuel_record_count
        )

        bus.maintenance_status = 'ok'
        bus.maintenance_label = 'Sin alerta'

        next_km = bus.next_maintenance_mileage or 0
        current_km = bus.current_mileage or 0

        if next_km:
            remaining = next_km - current_km
            if remaining <= 0:
                bus.maintenance_status = 'danger'
                bus.maintenance_label = 'Mantención vencida'
            elif remaining <= 1000:
                bus.maintenance_status = 'warning'
                bus.maintenance_label = f'{remaining:,} km restantes'
            else:
                bus.maintenance_status = 'success'
                bus.maintenance_label = f'{remaining:,} km restantes'

    total_buses = len(buses)
    active_count = sum(1 for bus in buses if bus.is_active)
    inactive_count = sum(1 for bus in buses if not bus.is_active)
    total_seats = sum(bus.real_seat_count for bus in buses)
    future_trips = sum(bus.future_trip_count for bus in buses)

    context = {
        'buses': buses,
        'query': query,
        'status_filter': status_filter,
        'total_buses': total_buses,
        'active_count': active_count,
        'inactive_count': inactive_count,
        'total_seats': total_seats,
        'future_trips': future_trips,
    }

    return render(
        request,
        'coordinator/bus_list.html',
        context,
    )


@login_required
@coordinator_required
def bus_editor(request, bus_id=None):
    """
    Editor avanzado de buses con protección de integridad entre
    el plano visual (layout/numeración/servicios) y los Seat reales.
    """
    if bus_id:
        bus = get_object_or_404(Bus, pk=bus_id)
    else:
        bus = Bus()

    def safe_json_loads(val):
        try:
            parsed = json.loads(val) if val else []
            return parsed if isinstance(parsed, list) else []
        except Exception:
            return []

    if request.method == 'POST':
        try:
            company_id = request.POST.get('company')
            plate = request.POST.get('plate', '').upper().strip()
            model = request.POST.get('model', '').strip()

            year_val = request.POST.get('year')
            year = int(year_val) if year_val and year_val.isdigit() else 2024

            floors = int(request.POST.get('floors', 1))
            rows_lower = int(request.POST.get('rows_lower', 5))
            rows_upper = int(request.POST.get('rows_upper', 0))
            cols = int(request.POST.get('cols', 4))

            prefix_lower = request.POST.get('prefix_lower', '')
            prefix_upper = request.POST.get('prefix_upper', '')

            technical_review_expiry = request.POST.get('technical_review_expiry') or None
            insurance_expiry = request.POST.get('insurance_expiry') or None
            permit_expiry = request.POST.get('permit_expiry') or None
            last_maintenance = request.POST.get('last_maintenance') or None

            if not company_id:
                raise ValidationError("Debe seleccionar una empresa.")
            if not plate:
                raise ValidationError("La patente es obligatoria.")
            if floors not in (1, 2):
                raise ValidationError("El bus sólo puede tener 1 o 2 pisos.")
            if rows_lower < 1:
                raise ValidationError("El piso inferior debe tener al menos una fila.")
            if floors == 2 and rows_upper < 1:
                raise ValidationError("Un bus de 2 pisos debe tener filas en el piso superior.")
            if cols < 1 or cols > 6:
                raise ValidationError("La cantidad de columnas debe estar entre 1 y 6.")

            lower_size = rows_lower * cols
            upper_size = rows_upper * cols if floors == 2 else 0

            layout_lower = safe_json_loads(request.POST.get('layout_lower'))
            layout_upper = safe_json_loads(request.POST.get('layout_upper'))
            numbers_lower = safe_json_loads(request.POST.get('numbers_lower'))
            numbers_upper = safe_json_loads(request.POST.get('numbers_upper'))
            services_lower = safe_json_loads(request.POST.get('services_lower'))
            services_upper = safe_json_loads(request.POST.get('services_upper'))

            layout_lower = (layout_lower + ['L'] * lower_size)[:lower_size]
            numbers_lower = (numbers_lower + [''] * lower_size)[:lower_size]
            services_lower = (services_lower + ['semi_cama'] * lower_size)[:lower_size]

            if floors == 2:
                layout_upper = (layout_upper + ['L'] * upper_size)[:upper_size]
                numbers_upper = (numbers_upper + [''] * upper_size)[:upper_size]
                services_upper = (services_upper + ['semi_cama'] * upper_size)[:upper_size]
            else:
                layout_upper = []
                numbers_upper = []
                services_upper = []

            next_counter = 1
            numbers_lower, next_counter = assign_missing_numbers(
                numbers_lower,
                layout_lower,
                prefix_lower,
                next_counter,
            )
            if floors == 2:
                numbers_upper, _ = assign_missing_numbers(
                    numbers_upper,
                    layout_upper,
                    prefix_upper,
                    next_counter,
                )

            seatmap_changed = not bus.pk

            if bus.pk:
                seatmap_changed = any([
                    bus.floors != floors,
                    bus.rows_lower != rows_lower,
                    bus.rows_upper != rows_upper,
                    bus.cols != cols,
                    (bus.prefix_lower or '') != prefix_lower,
                    (bus.prefix_upper or '') != prefix_upper,
                    list(bus.layout_lower or []) != layout_lower,
                    list(bus.layout_upper or []) != layout_upper,
                    list(bus.numbers_lower or []) != numbers_lower,
                    list(bus.numbers_upper or []) != numbers_upper,
                    list(bus.services_lower or []) != services_lower,
                    list(bus.services_upper or []) != services_upper,
                ])

            if bus.pk and seatmap_changed:
                future_trips_count = Trip.objects.filter(
                    bus=bus,
                    departure__gt=timezone.now(),
                ).count()

                ticket_count = Ticket.objects.filter(
                    seat__bus=bus,
                ).count()

                booking_seat_count = Seat.objects.filter(
                    bus=bus,
                    booking_order_items__isnull=False,
                ).distinct().count()

                blockers = []

                if future_trips_count:
                    blockers.append(f"{future_trips_count} viaje(s) futuro(s)")
                if ticket_count:
                    blockers.append(f"{ticket_count} ticket(s) asociado(s)")
                if booking_seat_count:
                    blockers.append(
                        f"{booking_seat_count} asiento(s) en reservas web"
                    )

                if blockers:
                    raise ValidationError(
                        "No se guardaron cambios en el plano de asientos. "
                        f"El bus {bus.plate} tiene "
                        + ", ".join(blockers)
                        + ". Para proteger tickets, reservas y viajes, "
                          "la distribución actual permanece intacta."
                    )

            with transaction.atomic():
                if bus.pk:
                    bus = Bus.objects.select_for_update().get(pk=bus.pk)

                bus.company_id = company_id
                bus.plate = plate
                bus.model = model
                bus.year = year
                bus.floors = floors
                bus.rows_lower = rows_lower
                bus.rows_upper = rows_upper
                bus.cols = cols
                bus.prefix_lower = prefix_lower
                bus.prefix_upper = prefix_upper
                bus.technical_review_expiry = technical_review_expiry
                bus.insurance_expiry = insurance_expiry
                bus.permit_expiry = permit_expiry
                bus.last_maintenance = last_maintenance
                bus.layout_lower = layout_lower
                bus.layout_upper = layout_upper
                bus.numbers_lower = numbers_lower
                bus.numbers_upper = numbers_upper
                bus.services_lower = services_lower
                bus.services_upper = services_upper
                bus.save()

                if seatmap_changed:
                    created = bus.regenerate_seats()
                    messages.success(
                        request,
                        f'Plano de asientos actualizado para {bus.plate}. '
                        f'{created} asiento(s) físicos sincronizados.'
                    )

                messages.success(
                    request,
                    f'Bus {bus.plate} guardado correctamente.'
                )

            return redirect('coordinator:bus_list')

        except ValidationError as e:
            messages.error(request, str(e))
        except Exception as e:
            messages.error(
                request,
                f'No fue posible guardar el bus: {str(e)}'
            )

    companies = Company.objects.all().order_by('name')

    future_trips_count = 0
    ticket_count = 0
    booking_seat_count = 0
    seatmap_locked = False

    if bus.pk:
        future_trips_count = Trip.objects.filter(
            bus=bus,
            departure__gt=timezone.now(),
        ).count()

        ticket_count = Ticket.objects.filter(
            seat__bus=bus,
        ).count()

        booking_seat_count = Seat.objects.filter(
            bus=bus,
            booking_order_items__isnull=False,
        ).distinct().count()

        seatmap_locked = bool(
            future_trips_count
            or ticket_count
            or booking_seat_count
        )

    context = {
        'bus': bus,
        'companies': companies,
        'layout_lower_json': json.dumps(bus.layout_lower or []),
        'layout_upper_json': json.dumps(bus.layout_upper or []),
        'numbers_lower_json': json.dumps(bus.numbers_lower or []),
        'numbers_upper_json': json.dumps(bus.numbers_upper or []),
        'services_lower_json': json.dumps(bus.services_lower or []),
        'services_upper_json': json.dumps(bus.services_upper or []),
        'seatmap_locked': seatmap_locked,
        'future_trips_count': future_trips_count,
        'ticket_count': ticket_count,
        'booking_seat_count': booking_seat_count,
        'real_seat_count': Seat.objects.filter(bus=bus).count() if bus.pk else 0,
    }

    return render(
        request,
        'coordinator/bus_editor.html',
        context,
    )


@login_required
@coordinator_required
def buses_dashboard(request):
    """Tablero unificado para la gestión rápida de buses."""
    bus_to_edit = None
    edit_id = request.GET.get('edit')
    if edit_id:
        bus_to_edit = get_object_or_404(Bus, pk=edit_id)

    if request.method == 'POST':
        form = BusFullForm(request.POST, instance=bus_to_edit) if bus_to_edit else BusFullForm(request.POST)
        if form.is_valid():
            bus = form.save()
            bus.ensure_layouts()
            messages.success(request, f'Datos del bus {bus.plate} actualizados correctamente.')
            return redirect('coordinator:buses_dashboard')
        else:
            messages.error(request, f'Error al guardar: {form.errors}')
    else:
        form = BusFullForm(instance=bus_to_edit) if bus_to_edit else BusFullForm()

    query = request.GET.get('q', '').strip()
    buses_list = Bus.objects.select_related('company').all().order_by('company__name', 'plate')
    if query:
        buses_list = buses_list.filter(
            Q(plate__icontains=query) | Q(model__icontains=query) |
            Q(owner_first_name__icontains=query) | Q(owner_last_name__icontains=query) |
            Q(brand__icontains=query)
        )

    paginator = Paginator(buses_list, 10)
    buses_page = paginator.get_page(request.GET.get('page'))

    context = {
        'form': form,
        'buses': buses_page,
        'query': query,
        'edit_mode': bool(bus_to_edit),
        'bus_edit_id': bus_to_edit.id if bus_to_edit else None,
    }
    return render(request, 'buses/buses_full.html', context)


@login_required
@coordinator_required
def bus_duplicate(request, bus_id):
    """
    Duplica la configuración física de un bus usando una patente temporal
    única. El nuevo bus queda listo para que el coordinador cambie la patente.
    """
    original = get_object_or_404(Bus, pk=bus_id)

    base_plate = f"{original.plate}-COPIA"
    candidate = base_plate[:30]
    counter = 2

    while Bus.objects.filter(plate=candidate).exists():
        suffix = f"-{counter}"
        candidate = f"{base_plate[:30-len(suffix)]}{suffix}"
        counter += 1

    with transaction.atomic():
        new_bus = Bus(
            company=original.company,
            plate=candidate,
            model=original.model,
            year=original.year,
            floors=original.floors,
            rows_lower=original.rows_lower,
            rows_upper=original.rows_upper,
            cols=original.cols,
            prefix_lower=original.prefix_lower,
            prefix_upper=original.prefix_upper,
            layout_lower=list(original.layout_lower or []),
            layout_upper=list(original.layout_upper or []),
            numbers_lower=list(original.numbers_lower or []),
            numbers_upper=list(original.numbers_upper or []),
            services_lower=list(original.services_lower or []),
            services_upper=list(original.services_upper or []),
            is_active=False,
        )
        new_bus.save()
        created = new_bus.regenerate_seats()

    messages.success(
        request,
        (
            f'Bus duplicado como {new_bus.plate}. '
            f'Se crearon {created} asiento(s). '
            'Cambia la patente y revisa el plano antes de activarlo.'
        ),
    )
    return redirect('coordinator:bus_editor', bus_id=new_bus.id)


@login_required
@coordinator_required
@require_POST
def bus_toggle_active(request, bus_id):
    """
    Activa o desactiva un bus sin eliminar su historial.
    Un bus con viajes futuros no puede desactivarse.
    """
    with transaction.atomic():
        bus = get_object_or_404(
            Bus.objects.select_for_update(),
            pk=bus_id,
        )

        if bus.is_active:
            future_trips = Trip.objects.filter(
                bus=bus,
                departure__gt=timezone.now(),
            ).count()

            if future_trips:
                return JsonResponse(
                    {
                        'success': False,
                        'protected': True,
                        'message': (
                            f'No se puede desactivar el bus {bus.plate}: '
                            f'tiene {future_trips} viaje(s) futuro(s) programado(s).'
                        ),
                    },
                    status=409,
                )

            bus.is_active = False
            action = 'desactivado'
        else:
            seat_count = Seat.objects.filter(bus=bus).count()
            if seat_count == 0:
                return JsonResponse(
                    {
                        'success': False,
                        'message': (
                            f'El bus {bus.plate} no tiene asientos físicos. '
                            'Revise el plano antes de activarlo.'
                        ),
                    },
                    status=409,
                )

            bus.is_active = True
            action = 'activado'

        bus.save(update_fields=['is_active'])

    return JsonResponse(
        {
            'success': True,
            'message': f'Bus {bus.plate} {action} correctamente.',
            'is_active': bus.is_active,
        }
    )


def _bus_history_summary(bus):
    """Retorna referencias que impiden eliminar físicamente un bus."""
    references = []

    trip_count = Trip.objects.filter(bus=bus).count()
    ticket_count = Ticket.objects.filter(trip__bus=bus).count()
    maintenance_count = Maintenance.objects.filter(bus=bus).count()
    fuel_count = FuelRecord.objects.filter(bus=bus).count()
    document_count = BusDocument.objects.filter(bus=bus).count()

    if trip_count:
        references.append(f'{trip_count} viaje(s)')
    if ticket_count:
        references.append(f'{ticket_count} ticket(s)')
    if maintenance_count:
        references.append(f'{maintenance_count} mantención(es)')
    if fuel_count:
        references.append(f'{fuel_count} carga(s) de combustible')
    if document_count:
        references.append(f'{document_count} documento(s)')

    return references


@login_required
@coordinator_required
@require_POST
def bus_delete(request, bus_id):
    """
    Eliminación segura.

    Si existe cualquier historial operacional, el bus NO se elimina.
    Debe desactivarse para preservar trazabilidad.
    """
    bus = get_object_or_404(Bus, pk=bus_id)
    references = _bus_history_summary(bus)

    if references:
        return JsonResponse(
            {
                'success': False,
                'protected': True,
                'message': (
                    f'El bus {bus.plate} tiene historial: '
                    + ', '.join(references)
                    + '. No se puede eliminar. Desactívalo para conservar '
                      'la trazabilidad operacional.'
                ),
            },
            status=409,
        )

    try:
        with transaction.atomic():
            Seat.objects.filter(bus=bus).delete()
            plate = bus.plate
            bus.delete()

        return JsonResponse(
            {
                'success': True,
                'message': f'Bus {plate} eliminado correctamente.',
            }
        )
    except ProtectedError:
        return JsonResponse(
            {
                'success': False,
                'protected': True,
                'message': (
                    f'El bus {bus.plate} tiene referencias protegidas. '
                    'Desactívalo en lugar de eliminarlo.'
                ),
            },
            status=409,
        )
    except Exception as e:
        return JsonResponse(
            {'success': False, 'error': str(e)},
            status=400,
        )


@login_required
@coordinator_required
@require_POST
def bus_delete_massive(request):
    """
    Elimina únicamente buses sin historial.
    Nunca elimina viajes, tickets ni registros operacionales en cascada.
    """
    try:
        data = json.loads(request.body)
        ids = data.get('ids', [])

        if not ids:
            return JsonResponse(
                {'success': False, 'error': 'No se seleccionaron buses'},
                status=400,
            )

        buses = Bus.objects.filter(id__in=ids)
        deleted_count = 0
        errors = []

        for bus in buses:
            references = _bus_history_summary(bus)

            if references:
                errors.append(
                    f"{bus.plate}: " + ', '.join(references)
                )
                continue

            try:
                with transaction.atomic():
                    Seat.objects.filter(bus=bus).delete()
                    bus.delete()
                deleted_count += 1
            except Exception as e:
                errors.append(f"{bus.plate}: {str(e)}")

        if errors:
            return JsonResponse(
                {
                    'success': False,
                    'partial': deleted_count > 0,
                    'deleted': deleted_count,
                    'errors': errors,
                }
            )

        return JsonResponse(
            {'success': True, 'deleted': deleted_count}
        )

    except Exception as e:
        return JsonResponse(
            {'success': False, 'error': str(e)},
            status=400,
        )


@login_required
@coordinator_required
def api_bus_data(request, bus_id):
    """API que devuelve los datos de layout de un bus en formato JSON."""
    bus = get_object_or_404(Bus, pk=bus_id)
    bus.ensure_layouts()
    return JsonResponse({
        'id': bus.id,
        'floors': bus.floors,
        'rows_lower': bus.rows_lower,
        'rows_upper': bus.rows_upper,
        'cols': bus.cols,
        'layout_lower': bus.layout_lower,
        'layout_upper': bus.layout_upper,
        'numbers_lower': bus.numbers_lower,
        'numbers_upper': bus.numbers_upper,
        'services_lower': bus.services_lower,
        'services_upper': bus.services_upper,
        'prefix_lower': bus.prefix_lower,
        'prefix_upper': bus.prefix_upper,
    })


# ============================================================================
# GESTIÓN DE VIAJES
# ============================================================================

@login_required
@coordinator_required
def trip_list(request):
    """Lista todos los viajes con origen, destino y bus."""
    trips = Trip.objects.select_related('route__origin', 'route__destination', 'bus').all().order_by('-departure')
    return render(request, 'coordinator/trip_list.html', {'trips': trips})


@login_required
@coordinator_required
def trip_create_edit(request, trip_id=None):
    """Crear o editar un viaje individual."""
    trip = get_object_or_404(Trip, pk=trip_id) if trip_id else Trip()

    if request.method == 'POST':
        try:
            route_id = request.POST.get('route')
            bus_id = request.POST.get('bus')
            departure = make_aware_datetime(request.POST.get('departure'), "Salida")
            
            trip.route_id = route_id
            trip.bus_id = bus_id
            trip.departure = departure
            
            if request.POST.get('arrival'):
                trip.arrival = make_aware_datetime(request.POST.get('arrival'), "Llegada")
            
            trip.driver1_id = request.POST.get('driver1') or None
            trip.driver2_id = request.POST.get('driver2') or None
            trip.assistant_id = request.POST.get('assistant') or None

            if trip.bus_id:
                trip.seats_total = Seat.objects.filter(bus_id=trip.bus_id).count()
            else:
                trip.seats_total = 0

            if not trip.arrival and trip.route_id:
                route = Route.objects.get(pk=trip.route_id)
                trip.arrival = trip.departure + timedelta(minutes=route.duration_minutes)

            # Validar conflictos
            route = trip.route
            bus = trip.bus
            conflicts = validate_trip_conflicts(
                route, bus, trip.driver1_id, trip.driver2_id,
                trip.departure, trip.arrival, exclude_trip=trip if trip.pk else None
            )
            if conflicts:
                for conflict in conflicts:
                    messages.error(request, conflict)
                return redirect('coordinator:trip_create_edit', trip_id=trip.pk if trip.pk else None)

            trip.save()
            messages.success(request, 'Viaje guardado correctamente.')
            return redirect('coordinator:trip_list')

        except ValidationError as e:
            messages.error(request, str(e))
        except Exception as e:
            messages.error(request, f'Error: {str(e)}')

    routes = Route.objects.select_related('origin', 'destination').all()
    buses = Bus.objects.all()
    drivers = Driver.objects.filter(is_active=True).order_by('full_name')
    assistants = Assistant.objects.filter(is_active=True).order_by('full_name')

    return render(request, 'coordinator/trip_form.html', {
        'trip': trip,
        'routes': routes,
        'buses': buses,
        'drivers': drivers,
        'assistants': assistants,
    })


@login_required
@coordinator_required
def trips_dashboard(request):
    """Tablero de gestión de viajes con filtros y paginación."""
    # Limpiar mensajes antiguos
    storage = messages.get_messages(request)
    storage.used = True
    list(storage)

    trip_to_edit = None
    edit_id = request.GET.get('edit')
    if edit_id:
        trip_to_edit = get_object_or_404(Trip, pk=edit_id)

    if request.method == 'POST':
        form = TripForm(request.POST, instance=trip_to_edit) if trip_to_edit else TripForm(request.POST)
        if form.is_valid():
            trip = form.save(commit=False)
            if not trip.arrival and trip.route:
                trip.arrival = trip.departure + timedelta(minutes=trip.route.duration_minutes)
            if trip.bus:
                trip.seats_total = Seat.objects.filter(bus=trip.bus).count()
            
            # Validar conflictos
            conflicts = validate_trip_conflicts(
                trip.route, trip.bus, trip.driver1_id, trip.driver2_id,
                trip.departure, trip.arrival, exclude_trip=trip if trip.pk else None
            )
            if conflicts:
                for conflict in conflicts:
                    messages.error(request, conflict)
                return redirect('coordinator:trips_dashboard')
            
            trip.save()
            messages.success(request, f'Viaje {trip} procesado con éxito.')
            return redirect('coordinator:trips_dashboard')
        else:
            messages.error(request, f'Error al guardar: {form.errors}')
    else:
        form = TripForm(instance=trip_to_edit) if trip_to_edit else TripForm()

    query = request.GET.get('q', '').strip()
    trips_list = Trip.objects.select_related(
        'route__origin', 'route__destination', 'bus', 'driver1', 'driver2', 'assistant'
    ).all().order_by('departure')

    if query:
        trips_list = trips_list.filter(
            Q(route__origin__name__icontains=query) | Q(route__destination__name__icontains=query) |
            Q(bus__plate__icontains=query) | Q(driver1__full_name__icontains=query)
        )

    paginator = Paginator(trips_list, 10)
    trips_page = paginator.get_page(request.GET.get('page'))

    context = {
        'form': form,
        'trips': trips_page,
        'query': query,
        'edit_mode': bool(trip_to_edit),
        'trip_edit_id': trip_to_edit.id if trip_to_edit else None,
    }
    return render(request, 'viajes/viajes.html', context)


@login_required
@coordinator_required
def trip_change_bus(request, trip_id):
    """Reasigna un viaje a un bus diferente."""
    from booking.views import _build_trip_grid
    
    trip = get_object_or_404(
        Trip.objects.select_related('bus', 'route').select_for_update(),
        pk=trip_id
    )

    if request.method == 'POST':
        new_bus_id = request.POST.get('new_bus')
        if not new_bus_id:
            messages.error(request, "Debe seleccionar un bus nuevo.")
            return redirect('coordinator:trip_change_bus', trip_id=trip.id)

        # Bloquear el bus nuevo para evitar race conditions
        new_bus = get_object_or_404(Bus.objects.select_for_update(), pk=new_bus_id)
        reassign_map = {k.split('_')[1]: v for k, v in request.POST.items() if k.startswith('seat_')}

        try:
            with transaction.atomic():
                # Bloquear todos los tickets y asientos involucrados
                tickets = Ticket.objects.filter(trip=trip).select_related('seat').select_for_update()
                
                if not tickets.exists():
                    trip.bus = new_bus
                    trip.seats_total = Seat.objects.filter(bus=new_bus).count()
                    trip.save()
                    messages.success(request, f"Bus cambiado a {new_bus.plate} (sin pasajeros).")
                    return redirect('coordinator:trip_list')

                missing = [ticket.seat.number for ticket in tickets if str(ticket.seat.id) not in reassign_map]
                if missing:
                    raise ValidationError(f"Asientos sin reasignar: {', '.join(missing)}")

                # Bloquear los asientos de destino
                new_seat_ids = list(reassign_map.values())
                new_seats = Seat.objects.filter(pk__in=new_seat_ids, bus=new_bus).select_for_update()
                new_seats_dict = {str(s.id): s for s in new_seats}

                for ticket in tickets:
                    new_seat_id = reassign_map.get(str(ticket.seat.id))
                    if not new_seat_id or new_seat_id not in new_seats_dict:
                        raise ValidationError(f"Asiento destino no encontrado para {ticket.seat.number}")

                    new_seat = new_seats_dict[new_seat_id]
                    
                    # Verificar que el asiento no esté ocupado
                    if Ticket.objects.filter(trip=trip, seat=new_seat).exists():
                        raise ValidationError(f"El asiento {new_seat.number} ya está ocupado.")

                # Ejecutar la reasignación
                for ticket in tickets:
                    new_seat = new_seats_dict[reassign_map[str(ticket.seat.id)]]
                    old_seat = ticket.seat
                    old_seat.is_occupied = False
                    old_seat.save(update_fields=['is_occupied'])

                    ticket.seat = new_seat
                    ticket.save()

                    new_seat.is_occupied = True
                    new_seat.save(update_fields=['is_occupied'])

                trip.bus = new_bus
                trip.seats_total = Seat.objects.filter(bus=new_bus).count()
                trip.save()

                messages.success(request, f"Viaje reasignado a bus {new_bus.plate}.")
                return redirect('coordinator:trip_list')

        except ValidationError as e:
            messages.error(request, str(e))
        except Exception as e:
            messages.error(request, f"Error inesperado: {str(e)}")

        return redirect('coordinator:trip_change_bus', trip_id=trip.id)

    buses = Bus.objects.exclude(pk=trip.bus.pk).order_by('company__name', 'plate')
    current_lower, current_upper, cols = _build_trip_grid(trip)

    context = {
        'trip': trip,
        'buses': buses,
        'current_lower': current_lower,
        'current_upper': current_upper,
        'cols': cols,
    }
    return render(request, 'coordinator/trip_change_bus.html', context)


@login_required
@coordinator_required
def trip_delete(request, trip_id):
    """Elimina un viaje solo si no tiene tickets vendidos."""
    try:
        trip = Trip.objects.get(pk=trip_id)
    except Trip.DoesNotExist:
        messages.warning(request, 'El viaje que intenta eliminar ya no existe.')
        return redirect('coordinator:trips_dashboard')

    if Ticket.objects.filter(trip=trip).exists():
        messages.error(request, 'No se puede eliminar un viaje con tickets vendidos.')
        return redirect('coordinator:trips_dashboard')

    trip.delete()
    messages.success(request, 'Viaje eliminado correctamente.')
    return redirect('coordinator:trips_dashboard')


# ============================================================================
# GENERACIÓN MASIVA DE VIAJES Y CALENDARIO
# ============================================================================

@login_required
@coordinator_required
def generate_trips(request):
    """
    Genera múltiples viajes recurrentes en un rango de fechas.
    Incluye validaciones de conflictos de horario para bus y choferes.
    """
    from django.utils.dateparse import parse_date

    today = timezone.now().date()
    year = int(request.GET.get('year', today.year))
    month = int(request.GET.get('month', today.month))
    if month < 1 or month > 12:
        month = today.month
    if year < 2000 or year > 2100:
        year = today.year

    cal = calendar.monthcalendar(year, month)
    first_day = datetime(year, month, 1).date()
    last_day = (
        (datetime(year, month + 1, 1) - timedelta(days=1)).date()
        if month < 12
        else datetime(year, 12, 31).date()
    )

    existing_trips = Trip.objects.filter(
        departure__date__range=(first_day, last_day)
    ).values_list('departure__date', flat=True).distinct()
    existing_dates = set(existing_trips)

    month_days = []
    for week in cal:
        week_days = []
        for day in week:
            if day == 0:
                week_days.append(None)
            else:
                date_obj = datetime(year, month, day).date()
                has_trip = date_obj in existing_dates
                week_days.append({
                    'day': day,
                    'date': date_obj,
                    'has_trip': has_trip,
                })
        month_days.append(week_days)

    if request.method == 'POST':
        is_ajax = request.headers.get('X-Requested-With') == 'XMLHttpRequest'

        route_id = request.POST.get('route')
        bus_id = request.POST.get('bus')
        driver1_id = request.POST.get('driver1') or None
        driver2_id = request.POST.get('driver2') or None
        assistant_id = request.POST.get('assistant') or None
        departure_hour = request.POST.get('departure_hour')
        start_date_str = request.POST.get('start_date')
        end_date_str = request.POST.get('end_date')
        weekdays = request.POST.getlist('weekdays')
        action = request.POST.get('action', 'create')

        errors = []

        # ============================================================
        # VALIDACIONES BÁSICAS
        # ============================================================
        if not route_id:
            errors.append("Debe seleccionar una ruta.")
        if not bus_id:
            errors.append("Debe seleccionar un bus.")
        if not departure_hour:
            errors.append("Debe ingresar la hora de salida.")
        if not start_date_str or not end_date_str:
            errors.append("Debe ingresar fecha inicio y fecha fin.")
        if not weekdays:
            errors.append("Debe seleccionar al menos un día de la semana.")

        # ============================================================
        # VALIDACIONES DE FECHAS Y HORARIO
        # ============================================================
        if not errors:
            try:
                start_date = parse_date(start_date_str)
                end_date = parse_date(end_date_str)
                hour, minute = map(int, departure_hour.split(':'))
                selected_weekdays = [int(d) for d in weekdays]

                if not start_date or not end_date:
                    errors.append("Formato de fecha inválido.")
                elif start_date > end_date:
                    errors.append(
                        "La fecha de inicio no puede ser posterior a la fecha fin."
                    )

                if hour < 0 or hour > 23 or minute < 0 or minute > 59:
                    errors.append(
                        "La hora de salida debe ser válida (00:00 - 23:59)."
                    )

                if any(day < 1 or day > 7 for day in selected_weekdays):
                    errors.append("Los días de la semana seleccionados no son válidos.")

            except ValueError:
                errors.append("Formato de fecha u hora inválido.")
            except Exception as e:
                errors.append(f"Error en datos: {str(e)}")

        # ============================================================
        # VALIDACIONES DE NEGOCIO
        # ============================================================
        if not errors:
            try:
                route = Route.objects.select_related(
                    'origin',
                    'destination',
                ).get(pk=route_id)

                bus = Bus.objects.get(pk=bus_id)

                driver1 = (
                    Driver.objects.filter(pk=driver1_id).first()
                    if driver1_id else None
                )
                driver2 = (
                    Driver.objects.filter(pk=driver2_id).first()
                    if driver2_id else None
                )

                if not route.is_active:
                    errors.append("La ruta seleccionada no está activa.")

                if not bus.is_active:
                    errors.append("El bus seleccionado no está activo.")

                if route.origin == route.destination:
                    errors.append(
                        "El origen y destino de la ruta no pueden ser iguales."
                    )

                if driver1_id and not driver1:
                    errors.append("El chofer principal seleccionado no existe.")
                elif driver1 and not driver1.is_active:
                    errors.append("El chofer principal no está activo.")

                if driver2_id and not driver2:
                    errors.append("El chofer secundario seleccionado no existe.")
                elif driver2 and not driver2.is_active:
                    errors.append("El chofer secundario no está activo.")

                if (
                    driver1_id
                    and driver2_id
                    and str(driver1_id) == str(driver2_id)
                ):
                    errors.append(
                        "El chofer principal y el chofer secundario "
                        "no pueden ser la misma persona."
                    )

                if assistant_id:
                    assistant = Assistant.objects.filter(
                        pk=assistant_id,
                        is_active=True,
                    ).first()
                    if not assistant:
                        errors.append(
                            "El auxiliar seleccionado no existe o no está activo."
                        )

            except Route.DoesNotExist:
                errors.append("La ruta seleccionada no existe.")
            except Bus.DoesNotExist:
                errors.append("El bus seleccionado no existe.")
            except Exception as e:
                errors.append(f"Error validando datos: {str(e)}")

        if errors:
            error_msg = " | ".join(errors)

            if is_ajax:
                return JsonResponse(
                    {
                        'success': False,
                        'error': error_msg,
                    },
                    status=400,
                )

            for err in errors:
                messages.error(request, err)

            return redirect('coordinator:generate_trips')

        # ============================================================
        # VISTA PREVIA: analiza la programación sin crear registros
        # ============================================================
        if action == 'preview':
            preview_rows = []
            preview_stats = {
                'available': 0,
                'existing': 0,
                'bus_conflict': 0,
                'driver_conflict': 0,
                'total': 0,
            }

            current_date = start_date
            delta = timedelta(days=1)
            total_seats = Seat.objects.filter(bus=bus).count()

            while current_date <= end_date:
                if current_date.isoweekday() not in selected_weekdays:
                    current_date += delta
                    continue

                departure_dt = timezone.make_aware(
                    datetime.combine(
                        current_date,
                        datetime.strptime(departure_hour, '%H:%M').time(),
                    )
                )
                arrival_dt = departure_dt + timedelta(
                    minutes=route.duration_minutes
                )

                status = 'available'
                status_label = 'Disponible'
                detail = 'Se puede crear'

                exact_trip = Trip.objects.filter(
                    route=route,
                    bus=bus,
                    departure__date=current_date,
                    departure__hour=departure_dt.hour,
                    departure__minute=departure_dt.minute,
                ).first()

                if exact_trip:
                    status = 'existing'
                    status_label = 'Ya existe'
                    detail = 'Misma ruta, bus y hora'
                    preview_stats['existing'] += 1
                else:
                    bus_conflict = Trip.objects.filter(
                        bus=bus,
                        departure__lt=arrival_dt,
                        arrival__gt=departure_dt,
                    ).first()

                    if bus_conflict:
                        status = 'bus_conflict'
                        status_label = 'Bus ocupado'
                        detail = (
                            f'Conflicto con viaje #{bus_conflict.id} '
                            f'a las {timezone.localtime(bus_conflict.departure).strftime("%H:%M")}'
                        )
                        preview_stats['bus_conflict'] += 1
                    else:
                        driver_conflict = None
                        driver_label = ''

                        if driver1_id:
                            driver_conflict = Trip.objects.filter(
                                driver1_id=driver1_id,
                                departure__lt=arrival_dt,
                                arrival__gt=departure_dt,
                            ).first()
                            if driver_conflict:
                                driver_label = 'Chofer principal ocupado'

                        if not driver_conflict and driver2_id:
                            driver_conflict = Trip.objects.filter(
                                driver2_id=driver2_id,
                                departure__lt=arrival_dt,
                                arrival__gt=departure_dt,
                            ).first()
                            if driver_conflict:
                                driver_label = 'Chofer secundario ocupado'

                        if driver_conflict:
                            status = 'driver_conflict'
                            status_label = driver_label
                            detail = (
                                f'Conflicto con viaje #{driver_conflict.id} '
                                f'a las {timezone.localtime(driver_conflict.departure).strftime("%H:%M")}'
                            )
                            preview_stats['driver_conflict'] += 1
                        else:
                            preview_stats['available'] += 1

                preview_stats['total'] += 1
                preview_rows.append({
                    'date': current_date.strftime('%d/%m/%Y'),
                    'date_iso': current_date.isoformat(),
                    'departure': departure_dt.strftime('%H:%M'),
                    'arrival': arrival_dt.strftime('%H:%M'),
                    'status': status,
                    'status_label': status_label,
                    'detail': detail,
                })

                current_date += delta

            return JsonResponse({
                'success': True,
                'preview': True,
                'rows': preview_rows,
                'stats': preview_stats,
                'summary': {
                    'route': str(route),
                    'bus': f'{bus.plate} - {bus.model or "Sin modelo"}',
                    'departure_hour': departure_hour,
                    'start_date': start_date.strftime('%d/%m/%Y'),
                    'end_date': end_date.strftime('%d/%m/%Y'),
                    'total_seats': total_seats,
                },
            })

        created_count = 0
        skipped_count = 0
        conflict_count = 0
        current_date = start_date
        delta = timedelta(days=1)

        try:
            with transaction.atomic():
                # Bloqueamos ruta y bus durante la generación para reducir
                # condiciones de carrera entre dos coordinadores.
                route = Route.objects.select_for_update().get(pk=route_id)
                bus = Bus.objects.select_for_update().get(pk=bus_id)

                total_seats = Seat.objects.filter(bus=bus).count()

                # Pre-cargar viajes del BUS seleccionado en el rango.
                # Se utiliza para detectar duplicados exactos sin hacer una
                # consulta adicional por cada fecha.
                existing_trips_dict = {}

                trips_in_range = Trip.objects.filter(
                    bus_id=bus_id,
                    departure__date__range=(start_date, end_date),
                ).select_related(
                    'route',
                    'bus',
                    'driver1',
                    'driver2',
                )

                for trip in trips_in_range:
                    date_key = trip.departure.date()
                    existing_trips_dict.setdefault(
                        date_key,
                        [],
                    ).append(trip)

                while current_date <= end_date:
                    day_of_week = current_date.isoweekday()

                    # Si el día no está marcado en el formulario,
                    # avanzamos sin realizar ninguna validación adicional.
                    if day_of_week not in selected_weekdays:
                        current_date += delta
                        continue

                    departure_dt = timezone.make_aware(
                        datetime.combine(
                            current_date,
                            datetime.strptime(
                                departure_hour,
                                '%H:%M',
                            ).time(),
                        )
                    )

                    arrival_dt = departure_dt + timedelta(
                        minutes=route.duration_minutes
                    )

                    # ====================================================
                    # 1. DUPLICADO EXACTO
                    # ====================================================
                    # Se considera duplicado sólo si coinciden:
                    # ruta + bus + fecha + hora de salida.
                    existing_on_date = existing_trips_dict.get(
                        current_date,
                        [],
                    )

                    existing_trip = None

                    for trip in existing_on_date:
                        same_route = trip.route_id == route.id
                        same_bus = trip.bus_id == bus.id
                        same_departure_time = (
                            trip.departure.hour == departure_dt.hour
                            and trip.departure.minute == departure_dt.minute
                        )

                        if (
                            same_route
                            and same_bus
                            and same_departure_time
                        ):
                            existing_trip = trip
                            break

                    if existing_trip:
                        skipped_count += 1
                        current_date += delta
                        continue

                    # ====================================================
                    # 2. CONFLICTO DE BUS
                    # ====================================================
                    bus_conflict = Trip.objects.filter(
                        bus=bus,
                        departure__lt=arrival_dt,
                        arrival__gt=departure_dt,
                    ).exists()

                    if bus_conflict:
                        conflict_count += 1
                        current_date += delta
                        continue

                    # ====================================================
                    # 3. CONFLICTO CHOFER PRINCIPAL
                    # ====================================================
                    driver1_conflict = False

                    if driver1_id:
                        driver1_conflict = Trip.objects.filter(
                            driver1_id=driver1_id,
                            departure__lt=arrival_dt,
                            arrival__gt=departure_dt,
                        ).exists()

                    if driver1_conflict:
                        conflict_count += 1
                        current_date += delta
                        continue

                    # ====================================================
                    # 4. CONFLICTO CHOFER SECUNDARIO
                    # ====================================================
                    driver2_conflict = False

                    if driver2_id:
                        driver2_conflict = Trip.objects.filter(
                            driver2_id=driver2_id,
                            departure__lt=arrival_dt,
                            arrival__gt=departure_dt,
                        ).exists()

                    if driver2_conflict:
                        conflict_count += 1
                        current_date += delta
                        continue

                    # ====================================================
                    # 5. CREAR VIAJE
                    # ====================================================
                    new_trip = Trip.objects.create(
                        route=route,
                        bus=bus,
                        driver1_id=driver1_id,
                        driver2_id=driver2_id,
                        assistant_id=assistant_id,
                        departure=departure_dt,
                        arrival=arrival_dt,
                        seats_total=total_seats,
                    )

                    created_count += 1

                    # Agregar el nuevo viaje al diccionario local.
                    # Esto permite detectar duplicados dentro de la misma
                    # ejecución sin volver a consultar la base.
                    existing_trips_dict.setdefault(
                        current_date,
                        [],
                    ).append(new_trip)

                    current_date += delta

            # ============================================================
            # MENSAJE DE RESULTADO
            # ============================================================
            message_parts = []

            if created_count > 0:
                message_parts.append(
                    f"✅ {created_count} viajes creados"
                )

            if skipped_count > 0:
                message_parts.append(
                    f"⏭️ {skipped_count} omitidos (ya existían)"
                )

            if conflict_count > 0:
                message_parts.append(
                    f"⚠️ {conflict_count} con conflictos de horario "
                    "(no creados)"
                )

            if not message_parts:
                message_parts.append(
                    "No se crearon viajes. Verifica los parámetros."
                )

            message = " | ".join(message_parts)

            if is_ajax:
                return JsonResponse({
                    'success': True,
                    'message': message,
                    'stats': {
                        'created': created_count,
                        'skipped': skipped_count,
                        'conflicts': conflict_count,
                    },
                })

            if created_count > 0:
                messages.success(request, message)
            else:
                messages.warning(request, message)

            return redirect('coordinator:trips_dashboard')

        except Exception as e:
            if is_ajax:
                return JsonResponse(
                    {
                        'success': False,
                        'error': str(e),
                    },
                    status=500,
                )

            messages.error(
                request,
                f"Error al generar viajes: {str(e)}",
            )
            return redirect('coordinator:generate_trips')

    routes = Route.objects.select_related(
        'origin',
        'destination',
    ).filter(is_active=True)

    buses = Bus.objects.filter(is_active=True)
    drivers = Driver.objects.filter(is_active=True)
    assistants = Assistant.objects.filter(is_active=True)

    context = {
        'routes': routes,
        'buses': buses,
        'drivers': drivers,
        'assistants': assistants,
        'year': year,
        'month': month,
        'month_days': month_days,
        'first_day': first_day,
        'last_day': last_day,
        'today': today,
        'existing_dates': existing_dates,
        'weekday_choices': [
            (1, 'Lunes'),
            (2, 'Martes'),
            (3, 'Miércoles'),
            (4, 'Jueves'),
            (5, 'Viernes'),
            (6, 'Sábado'),
            (7, 'Domingo'),
        ],
    }

    return render(
        request,
        'coordinator/generate_trips.html',
        context,
    )


@login_required
@coordinator_required
def api_trips_calendar(request):
    """
    Endpoint para FullCalendar: devuelve viajes en el rango de fechas.
    """
    start_str = request.GET.get('start')
    end_str = request.GET.get('end')
    if not start_str or not end_str:
        return JsonResponse([], safe=False)

    try:
        start = timezone.make_aware(datetime.fromisoformat(start_str.replace('Z', '+00:00')))
        end = timezone.make_aware(datetime.fromisoformat(end_str.replace('Z', '+00:00')))
    except Exception:
        return JsonResponse([], safe=False)

    trips = Trip.objects.filter(departure__range=(start, end)).select_related(
        'route__origin', 'route__destination', 'bus'
    ).annotate(
        has_tickets=Exists(Ticket.objects.filter(trip=OuterRef('pk')))
    )

    events = []
    for trip in trips:
        events.append({
            'id': trip.id,
            'title': f"{trip.route.origin.name} → {trip.route.destination.name}",
            'start': trip.departure.isoformat(),
            'end': trip.arrival.isoformat() if trip.arrival else None,
            'extendedProps': {
                'id': trip.id,
                'route': str(trip.route),
                'bus': trip.bus.plate,
                'departure_date': trip.departure.strftime('%Y-%m-%d'),
                'departure_time': trip.departure.strftime('%H:%M'),
                'has_tickets': trip.has_tickets,
            }
        })
    return JsonResponse(events, safe=False)


@login_required
@coordinator_required
@require_POST
def delete_trip_by_date(request):
    """Elimina un viaje específico (usado desde el calendario)."""
    trip_id = request.POST.get('trip_id')
    if not trip_id:
        return JsonResponse({'success': False, 'error': 'ID de viaje no proporcionado'})
    trip = get_object_or_404(Trip, pk=trip_id)
    if Ticket.objects.filter(trip=trip).exists():
        return JsonResponse({'success': False, 'error': 'El viaje tiene tickets vendidos, no se puede eliminar.'})
    trip.delete()
    return JsonResponse({'success': True, 'message': 'Viaje eliminado correctamente.'})


# ============================================================================
# GESTIÓN DE CIUDADES
# ============================================================================

@login_required
@coordinator_required
def city_list(request):
    cities = City.objects.all().order_by("name")
    return render(request, "coordinator/city_list.html", {"cities": cities})


@login_required
@coordinator_required
def city_create_edit(request, city_id=None):
    city = get_object_or_404(City, pk=city_id) if city_id else City()
    if request.method == "POST":
        city.name = request.POST.get("name")
        city.save()
        messages.success(request, f"Ciudad '{city.name}' guardada.")
        return redirect("coordinator:city_list")
    return render(request, "coordinator/city_form.html", {"city": city})


@login_required
@coordinator_required
def city_delete(request, city_id):
    city = get_object_or_404(City, pk=city_id)
    city.delete()
    messages.success(request, "Ciudad eliminada.")
    return redirect("coordinator:city_list")


@login_required
@coordinator_required
def cities_dashboard(request):
    city_to_edit = None
    edit_id = request.GET.get('edit')
    if edit_id:
        city_to_edit = get_object_or_404(City, pk=edit_id)

    if request.method == 'POST':
        form = CityForm(request.POST, instance=city_to_edit) if city_to_edit else CityForm(request.POST)
        if form.is_valid():
            city = form.save()
            messages.success(request, f'Ciudad "{city.name}" guardada.')
            return redirect('coordinator:cities_dashboard')
        else:
            messages.error(request, 'Por favor corrige los errores.')
    else:
        form = CityForm(instance=city_to_edit) if city_to_edit else CityForm()

    query = request.GET.get('q', '').strip()
    cities_list = City.objects.all().order_by('name')
    if query:
        cities_list = cities_list.filter(name__icontains=query)

    paginator = Paginator(cities_list, 10)
    cities_page = paginator.get_page(request.GET.get('page'))

    context = {
        'form': form,
        'cities': cities_page,
        'query': query,
        'edit_mode': bool(city_to_edit),
        'city_edit_id': city_to_edit.id if city_to_edit else None,
    }
    return render(request, 'ciudades/ciudades.html', context)


# ============================================================================
# GESTIÓN DE TERMINALES
# ============================================================================

@login_required
@coordinator_required
def terminal_list(request):
    terminals = Terminal.objects.select_related("city").all().order_by("city__name", "name")
    return render(request, "coordinator/terminal_list.html", {"terminals": terminals})


@login_required
@coordinator_required
def terminal_create_edit(request, terminal_id=None):
    terminal = get_object_or_404(Terminal, pk=terminal_id) if terminal_id else Terminal()
    if request.method == "POST":
        terminal.name = request.POST.get("name")
        terminal.city_id = request.POST.get("city")
        terminal.address = request.POST.get("address", "")
        terminal.is_active = "is_active" in request.POST
        terminal.save()
        messages.success(request, f"Terminal '{terminal.name}' guardada.")
        return redirect("coordinator:terminal_list")
    cities = City.objects.all()
    return render(request, "coordinator/terminal_form.html", {"terminal": terminal, "cities": cities})


@login_required
@coordinator_required
def terminal_delete(request, terminal_id):
    terminal = get_object_or_404(Terminal, pk=terminal_id)
    terminal.delete()
    messages.success(request, "Terminal eliminada.")
    return redirect("coordinator:terminal_list")


@login_required
@coordinator_required
def terminals_dashboard(request):
    terminal_to_edit = None
    edit_id = request.GET.get('edit')
    if edit_id:
        terminal_to_edit = get_object_or_404(Terminal, pk=edit_id)

    if request.method == 'POST':
        form = TerminalForm(request.POST, instance=terminal_to_edit) if terminal_to_edit else TerminalForm(request.POST)
        if form.is_valid():
            terminal = form.save()
            messages.success(request, f'Terminal {terminal.name} guardada.')
            return redirect('coordinator:terminals_dashboard')
        else:
            messages.error(request, 'Por favor corrige los errores del formulario.')
    else:
        form = TerminalForm(instance=terminal_to_edit) if terminal_to_edit else TerminalForm()

    query = request.GET.get('q', '').strip()
    terminals_list = Terminal.objects.select_related('city').all().order_by('city__name', 'name')
    if query:
        terminals_list = terminals_list.filter(
            Q(name__icontains=query) | Q(city__name__icontains=query) | Q(address__icontains=query)
        )

    paginator = Paginator(terminals_list, 10)
    terminals_page = paginator.get_page(request.GET.get('page'))

    context = {
        'form': form,
        'terminals': terminals_page,
        'query': query,
        'edit_mode': bool(terminal_to_edit),
        'terminal_edit_id': terminal_to_edit.id if terminal_to_edit else None,
    }
    return render(request, 'terminales/terminales.html', context)


# ============================================================================
# GESTIÓN DE RUTAS
# ============================================================================

@login_required
@coordinator_required
def route_list(request):
    routes = Route.objects.select_related("origin", "destination", "origin_terminal", "destination_terminal").all()
    return render(request, "coordinator/route_list.html", {"routes": routes})


@login_required
@coordinator_required
def route_create_edit(request, route_id=None):
    route = get_object_or_404(Route, pk=route_id) if route_id else Route()
    if request.method == "POST":
        route.origin_id = request.POST.get("origin")
        route.destination_id = request.POST.get("destination")
        route.origin_terminal_id = request.POST.get("origin_terminal") or None
        route.destination_terminal_id = request.POST.get("destination_terminal") or None
        route.duration_minutes = int(request.POST.get("duration_minutes", 120))
        route.base_price = Decimal(request.POST.get("base_price", 0))
        route.save()
        messages.success(request, f"Ruta {route} guardada.")
        return redirect("coordinator:route_list")
    cities = City.objects.all()
    terminals = Terminal.objects.all()
    return render(request, "coordinator/route_form.html", {
        "route": route,
        "cities": cities,
        "terminals": terminals
    })


@login_required
@coordinator_required
def route_delete(request, route_id):
    route = get_object_or_404(Route, pk=route_id)
    route.delete()
    messages.success(request, "Ruta eliminada.")
    return redirect("coordinator:route_list")


@login_required
@coordinator_required
def routes_dashboard(request):
    route_to_edit = None
    edit_id = request.GET.get('edit')
    if edit_id:
        route_to_edit = get_object_or_404(Route, pk=edit_id)

    if request.method == 'POST':
        if route_to_edit:
            form = RouteForm(request.POST, instance=route_to_edit)
            formset = RouteStopFormSet(request.POST, instance=route_to_edit)
        else:
            form = RouteForm(request.POST)
            formset = RouteStopFormSet(request.POST)

        if form.is_valid() and formset.is_valid():
            route = form.save()
            formset.instance = route
            formset.save()
            messages.success(request, f'Ruta {route} guardada correctamente.')
            return redirect('coordinator:routes_dashboard')
        else:
            messages.error(request, 'Por favor corrige los errores del formulario.')
    else:
        if route_to_edit:
            form = RouteForm(instance=route_to_edit)
            formset = RouteStopFormSet(instance=route_to_edit)
        else:
            form = RouteForm()
            formset = RouteStopFormSet()

    query = request.GET.get('q', '').strip()
    routes_list = Route.objects.select_related('origin', 'destination').all().order_by('origin__name', 'destination__name')
    if query:
        routes_list = routes_list.filter(
            Q(origin__name__icontains=query) | Q(destination__name__icontains=query)
        )

    paginator = Paginator(routes_list, 10)
    routes_page = paginator.get_page(request.GET.get('page'))

    context = {
        'form': form,
        'formset': formset,
        'routes': routes_page,
        'query': query,
        'edit_mode': bool(route_to_edit),
        'route_edit_id': route_to_edit.id if route_to_edit else None,
        'cities': City.objects.all(),
        'terminals': Terminal.objects.all(),
    }
    return render(request, 'rutas/rutas.html', context)


# ============================================================================
# GESTIÓN DE CHOFERES
# ============================================================================

_DRIVER_DOC_SYNC_NOTE = "[SYNC_FICHA_CHOFER]"


def _sync_driver_document_expiry(driver, doc_type, expiry_date, document_number=""):
    """
    Mantiene un documento operacional sincronizado desde la ficha del chofer.

    Se usa un registro marcado internamente para no modificar ni eliminar
    documentos históricos que hayan sido cargados manualmente.
    """
    synced_qs = DriverDocument.objects.filter(
        driver=driver,
        doc_type=doc_type,
        notes=_DRIVER_DOC_SYNC_NOTE,
    ).order_by('-created_at', '-id')

    synced_doc = synced_qs.first()

    # Si el usuario limpia la fecha, eliminamos únicamente el documento
    # autogenerado por esta ficha; no tocamos archivos/documentos manuales.
    if not expiry_date:
        synced_qs.delete()
        return

    if synced_doc:
        changed_fields = []

        if synced_doc.expiry_date != expiry_date:
            synced_doc.expiry_date = expiry_date
            changed_fields.append('expiry_date')

        if doc_type == 'license':
            number = document_number or ''
            if synced_doc.document_number != number:
                synced_doc.document_number = number
                changed_fields.append('document_number')

        if changed_fields:
            synced_doc.save(update_fields=changed_fields)

        # Evita duplicados antiguos del propio sincronizador.
        synced_qs.exclude(pk=synced_doc.pk).delete()
        return

    DriverDocument.objects.create(
        driver=driver,
        doc_type=doc_type,
        document_number=(document_number or '') if doc_type == 'license' else '',
        expiry_date=expiry_date,
        notes=_DRIVER_DOC_SYNC_NOTE,
    )


def _sync_driver_documents(driver):
    """Sincroniza licencia, certificado médico y antecedentes."""
    _sync_driver_document_expiry(
        driver,
        'license',
        driver.license_expiry,
        driver.license_number,
    )
    _sync_driver_document_expiry(
        driver,
        'medical',
        driver.medical_cert_expiry,
    )
    _sync_driver_document_expiry(
        driver,
        'background',
        driver.background_check_expiry,
    )


@login_required
@coordinator_required
def driver_list(request):
    drivers = Driver.objects.all().order_by("full_name")
    return render(request, "coordinator/driver_list.html", {"drivers": drivers})


@login_required
@coordinator_required
def driver_create_edit(request, driver_id=None):
    driver = get_object_or_404(Driver, pk=driver_id) if driver_id else Driver()
    if request.method == "POST":
        driver.license_expiry = request.POST.get('license_expiry') or None
        driver.medical_cert_expiry = request.POST.get('medical_cert_expiry') or None
        driver.background_check_expiry = request.POST.get('background_check_expiry') or None
        driver.notes = request.POST.get('notes', '')
        driver.full_name = request.POST.get("full_name")
        driver.rut = request.POST.get("rut")
        driver.email = request.POST.get("email", "")
        driver.phone = request.POST.get("phone", "")
        driver.license_number = request.POST.get("license_number", "")
        driver.is_active = "is_active" in request.POST
        if 'photo' in request.FILES:
            driver.photo = request.FILES['photo']
        with transaction.atomic():
            driver.save()
            _sync_driver_documents(driver)
        messages.success(request, f"Chofer {driver.full_name} guardado.")
        return redirect("coordinator:driver_list")
    return render(request, "coordinator/driver_form.html", {"driver": driver})


@login_required
@coordinator_required
def driver_delete(request, driver_id):
    driver = get_object_or_404(Driver, pk=driver_id)
    driver.delete()
    messages.success(request, "Chofer eliminado.")
    return redirect("coordinator:driver_list")


@login_required
@coordinator_required
def drivers_dashboard(request):
    """
    Alta/edición de choferes.
    Las fechas operacionales se sincronizan con DriverDocument para que
    alimenten automáticamente el centro de alertas y el dashboard.
    """
    driver_to_edit = None
    edit_id = request.GET.get('edit')

    if edit_id:
        driver_to_edit = get_object_or_404(Driver, pk=edit_id)

    if request.method == 'POST':
        form = (
            DriverForm(
                request.POST,
                request.FILES,
                instance=driver_to_edit,
            )
            if driver_to_edit
            else DriverForm(request.POST, request.FILES)
        )

        if form.is_valid():
            try:
                with transaction.atomic():
                    driver = form.save()
                    _sync_driver_documents(driver)

                messages.success(
                    request,
                    f'Chofer {driver.full_name} guardado y documentos sincronizados.'
                )
                return redirect('coordinator:drivers_dashboard')

            except Exception as e:
                messages.error(
                    request,
                    f'No fue posible guardar el chofer: {str(e)}'
                )
        else:
            messages.error(
                request,
                'Por favor corrige los errores del formulario.'
            )
    else:
        form = (
            DriverForm(instance=driver_to_edit)
            if driver_to_edit
            else DriverForm()
        )

    query = request.GET.get('q', '').strip()
    drivers_list = Driver.objects.all().order_by(
        '-is_active',
        'full_name',
    )

    if query:
        drivers_list = drivers_list.filter(
            Q(full_name__icontains=query)
            | Q(rut__icontains=query)
        )

    paginator = Paginator(drivers_list, 10)
    drivers_page = paginator.get_page(request.GET.get('page'))

    context = {
        'form': form,
        'drivers': drivers_page,
        'query': query,
        'edit_mode': bool(driver_to_edit),
        'driver_edit_id': (
            driver_to_edit.id
            if driver_to_edit
            else None
        ),
    }

    return render(
        request,
        'choferes/choferes.html',
        context,
    )


# ============================================================================
# GESTIÓN DE AUXILIARES
# ============================================================================

@login_required
@coordinator_required
def assistant_list(request):
    assistants = Assistant.objects.all().order_by("full_name")
    return render(request, "coordinator/assistant_list.html", {"assistants": assistants})


@login_required
@coordinator_required
def assistant_create_edit(request, assistant_id=None):
    assistant = get_object_or_404(Assistant, pk=assistant_id) if assistant_id else Assistant()
    if request.method == "POST":
        assistant.full_name = request.POST.get("full_name")
        assistant.rut = request.POST.get("rut")
        assistant.email = request.POST.get("email", "")
        assistant.phone = request.POST.get("phone", "")
        assistant.is_active = "is_active" in request.POST
        if 'photo' in request.FILES:
            assistant.photo = request.FILES['photo']
        assistant.save()
        messages.success(request, f"Auxiliar {assistant.full_name} guardado.")
        return redirect("coordinator:assistant_list")
    return render(request, "coordinator/assistant_form.html", {"assistant": assistant})


@login_required
@coordinator_required
def assistant_delete(request, assistant_id):
    assistant = get_object_or_404(Assistant, pk=assistant_id)
    assistant.delete()
    messages.success(request, "Auxiliar eliminado.")
    return redirect("coordinator:assistant_list")


@login_required
@coordinator_required
def assistants_dashboard(request):
    """Tablero de gestión de auxiliares con paginación y búsqueda."""
    assistant_to_edit = None
    edit_id = request.GET.get('edit')
    if edit_id:
        assistant_to_edit = get_object_or_404(Assistant, pk=edit_id)

    if request.method == 'POST':
        form = AssistantForm(request.POST, request.FILES, instance=assistant_to_edit) if assistant_to_edit else AssistantForm(request.POST, request.FILES)
        if form.is_valid():
            assistant = form.save()
            messages.success(request, f'Auxiliar {assistant.full_name} guardado.')
            return redirect('coordinator:assistants_dashboard')
        else:
            messages.error(request, 'Por favor corrige los errores del formulario.')
    else:
        form = AssistantForm(instance=assistant_to_edit) if assistant_to_edit else AssistantForm()

    query = request.GET.get('q', '').strip()
    assistants_list = Assistant.objects.all().order_by('-is_active', 'full_name')
    if query:
        assistants_list = assistants_list.filter(Q(full_name__icontains=query) | Q(rut__icontains=query))

    paginator = Paginator(assistants_list, 10)
    assistants_page = paginator.get_page(request.GET.get('page'))

    context = {
        'form': form,
        'assistants': assistants_page,
        'query': query,
        'edit_mode': bool(assistant_to_edit),
        'assistant_edit_id': assistant_to_edit.id if assistant_to_edit else None,
    }
    return render(request, 'auxiliares/assistants.html', context)


# ============================================================================
# GESTIÓN DE AGENCIAS
# ============================================================================

@login_required
@coordinator_required
def agencies_dashboard(request):
    agency_to_edit = None
    edit_id = request.GET.get('edit')
    if edit_id:
        agency_to_edit = get_object_or_404(Agency, pk=edit_id)

    if request.method == 'POST':
        form = AgencyForm(request.POST, instance=agency_to_edit) if agency_to_edit else AgencyForm(request.POST)
        if form.is_valid():
            agency = form.save()
            messages.success(request, f'Agencia "{agency.name}" guardada.')
            return redirect('coordinator:agencies_dashboard')
        else:
            messages.error(request, 'Por favor corrige los errores del formulario.')
    else:
        form = AgencyForm(instance=agency_to_edit) if agency_to_edit else AgencyForm()

    query = request.GET.get('q', '').strip()
    agencies_list = Agency.objects.select_related('city').all().order_by('name')
    if query:
        agencies_list = agencies_list.filter(
            Q(name__icontains=query) | Q(city__name__icontains=query) | Q(address__icontains=query)
        )

    paginator = Paginator(agencies_list, 10)
    agencies_page = paginator.get_page(request.GET.get('page'))

    context = {
        'form': form,
        'agencies': agencies_page,
        'query': query,
        'edit_mode': bool(agency_to_edit),
        'agency_edit_id': agency_to_edit.id if agency_to_edit else None,
    }
    return render(request, 'agencias/agencias.html', context)


@login_required
@coordinator_required
def agency_delete(request, agency_id):
    agency = get_object_or_404(Agency, pk=agency_id)
    agency.delete()
    messages.success(request, "Agencia eliminada correctamente.")
    return redirect('coordinator:agencies_dashboard')


# ============================================================================
# DOCUMENTOS DE PERSONAL Y FLOTA
# ============================================================================

@login_required
@coordinator_required
def driver_documents(request, driver_id):
    driver = get_object_or_404(Driver, pk=driver_id)
    documents = DriverDocument.objects.filter(driver=driver).order_by('expiry_date')
    return render(request, 'coordinator/driver_documents.html', {'driver': driver, 'documents': documents})


@login_required
@coordinator_required
def driver_document_create(request, driver_id):
    driver = get_object_or_404(Driver, pk=driver_id)
    if request.method == 'POST':
        DriverDocument.objects.create(
            driver=driver,
            doc_type=request.POST.get('doc_type'),
            document_number=request.POST.get('doc_number', ''),
            issue_date=request.POST.get('issue_date') or None,
            expiry_date=request.POST.get('expiry_date'),
            notes=request.POST.get('notes', '')
        )
        messages.success(request, f'Documento agregado a {driver.full_name}')
        return redirect('coordinator:driver_documents', driver_id=driver.id)
    return render(request, 'coordinator/driver_document_form.html', {'driver': driver})


@login_required
@coordinator_required
def driver_document_edit(request, doc_id):
    doc = get_object_or_404(DriverDocument, pk=doc_id)
    if request.method == 'POST':
        doc.doc_type = request.POST.get('doc_type')
        doc.document_number = request.POST.get('doc_number', '')
        doc.issue_date = request.POST.get('issue_date') or None
        doc.expiry_date = request.POST.get('expiry_date')
        doc.notes = request.POST.get('notes', '')
        doc.save()
        messages.success(request, 'Documento actualizado')
        return redirect('coordinator:driver_documents', driver_id=doc.driver.id)
    return render(request, 'coordinator/driver_document_form.html', {'doc': doc, 'driver': doc.driver})


@login_required
@coordinator_required
def driver_document_delete(request, doc_id):
    doc = get_object_or_404(DriverDocument, pk=doc_id)
    driver_id = doc.driver.id
    doc.delete()
    messages.success(request, 'Documento eliminado')
    return redirect('coordinator:driver_documents', driver_id=driver_id)


@login_required
@coordinator_required
def bus_documents(request, bus_id):
    bus = get_object_or_404(Bus, pk=bus_id)
    documents = BusDocument.objects.filter(bus=bus).order_by('expiry_date')
    return render(request, 'coordinator/bus_documents.html', {'bus': bus, 'documents': documents})


@login_required
@coordinator_required
def bus_document_create(request, bus_id):
    bus = get_object_or_404(Bus, pk=bus_id)
    if request.method == 'POST':
        BusDocument.objects.create(
            bus=bus,
            doc_type=request.POST.get('doc_type'),
            document_number=request.POST.get('doc_number', ''),
            issue_date=request.POST.get('issue_date') or None,
            expiry_date=request.POST.get('expiry_date'),
            notes=request.POST.get('notes', '')
        )
        messages.success(request, f'Documento agregado a bus {bus.plate}')
        return redirect('coordinator:bus_documents', bus_id=bus.id)
    return render(request, 'coordinator/bus_document_form.html', {'bus': bus})


@login_required
@coordinator_required
def bus_document_edit(request, doc_id):
    doc = get_object_or_404(BusDocument, pk=doc_id)
    if request.method == 'POST':
        doc.doc_type = request.POST.get('doc_type')
        doc.document_number = request.POST.get('doc_number', '')
        doc.issue_date = request.POST.get('issue_date') or None
        doc.expiry_date = request.POST.get('expiry_date')
        doc.notes = request.POST.get('notes', '')
        doc.save()
        messages.success(request, 'Documento actualizado')
        return redirect('coordinator:bus_documents', bus_id=doc.bus.id)
    return render(request, 'coordinator/bus_document_form.html', {'doc': doc, 'bus': doc.bus})


@login_required
@coordinator_required
def bus_document_delete(request, doc_id):
    doc = get_object_or_404(BusDocument, pk=doc_id)
    bus_id = doc.bus.id
    doc.delete()
    messages.success(request, 'Documento eliminado')
    return redirect('coordinator:bus_documents', bus_id=bus_id)


@login_required
@coordinator_required
def expiring_documents(request):
    """
    Centro de alertas documentales.
    Clasifica documentos vencidos, urgentes (<= 7 días) y próximos (<= 30 días).
    """
    today = timezone.localdate()
    warning_days = 30
    urgent_days = 7
    expiry_limit = today + timedelta(days=warning_days)

    driver_docs = list(
        DriverDocument.objects.filter(
            expiry_date__isnull=False,
            expiry_date__lte=expiry_limit,
        )
        .select_related('driver')
        .order_by('expiry_date', 'driver__full_name')
    )

    bus_docs = list(
        BusDocument.objects.filter(
            expiry_date__isnull=False,
            expiry_date__lte=expiry_limit,
        )
        .select_related('bus')
        .order_by('expiry_date', 'bus__plate')
    )

    def decorate_document(doc, owner_type):
        days = (doc.expiry_date - today).days
        doc.days_remaining = days
        doc.owner_type = owner_type

        if owner_type == 'driver':
            doc.owner_name = doc.driver.full_name
            doc.owner_detail = doc.driver.rut
        else:
            doc.owner_name = doc.bus.plate
            doc.owner_detail = doc.bus.model or ''

        if days < 0:
            doc.alert_status = 'expired'
            doc.alert_label = 'Vencido'
            doc.remaining_label = f'Venció hace {abs(days)} día{"s" if abs(days) != 1 else ""}'
            doc.alert_order = 0
        elif days <= urgent_days:
            doc.alert_status = 'urgent'
            doc.alert_label = 'Urgente'
            if days == 0:
                doc.remaining_label = 'Vence hoy'
            else:
                doc.remaining_label = f'{days} día{"s" if days != 1 else ""}'
            doc.alert_order = 1
        else:
            doc.alert_status = 'warning'
            doc.alert_label = 'Por vencer'
            doc.remaining_label = f'{days} días'
            doc.alert_order = 2

        return doc

    driver_docs = [decorate_document(doc, 'driver') for doc in driver_docs]
    bus_docs = [decorate_document(doc, 'bus') for doc in bus_docs]

    all_docs = sorted(
        driver_docs + bus_docs,
        key=lambda doc: (
            doc.alert_order,
            doc.expiry_date,
            doc.owner_name.lower(),
        ),
    )

    expired_count = sum(1 for doc in all_docs if doc.alert_status == 'expired')
    urgent_count = sum(1 for doc in all_docs if doc.alert_status == 'urgent')
    warning_count = sum(1 for doc in all_docs if doc.alert_status == 'warning')

    context = {
        'all_docs': all_docs,
        'driver_docs': driver_docs,
        'bus_docs': bus_docs,
        'expired_count': expired_count,
        'urgent_count': urgent_count,
        'warning_count': warning_count,
        'attention_count': len(all_docs),
        'warning_days': warning_days,
        'urgent_days': urgent_days,
        'today': today,
    }
    return render(request, 'coordinator/expiring_documents.html', context)


# ============================================================================
# DETALLE DE VIAJE Y BUS
# ============================================================================

@login_required
@coordinator_required
def trip_detail(request, trip_id):
    trip = get_object_or_404(
        Trip.objects.select_related(
            'route__origin', 'route__destination', 'bus',
            'driver1', 'driver2', 'assistant'
        ).annotate(
            total_tickets=Count('tickets'),
            lower_tickets=Count('tickets', filter=Q(tickets__seat__deck=1)),
            upper_tickets=Count('tickets', filter=Q(tickets__seat__deck=2)),
        ),
        pk=trip_id
    )

    tickets = Ticket.objects.filter(trip=trip).select_related('seat', 'customer')

    total_tickets = trip.total_tickets
    lower_occupied = trip.lower_tickets
    upper_occupied = trip.upper_tickets if trip.bus.floors == 2 else 0

    lower_seats = Seat.objects.filter(bus=trip.bus, deck=1).count()
    upper_seats = Seat.objects.filter(bus=trip.bus, deck=2).count() if trip.bus.floors == 2 else 0

    occupancy_rate = (total_tickets / trip.seats_total * 100) if trip.seats_total else 0
    lower_occupancy = (lower_occupied / lower_seats * 100) if lower_seats else 0
    upper_occupancy = (upper_occupied / upper_seats * 100) if upper_seats else 0

    context = {
        'trip': trip,
        'tickets': tickets,
        'occupancy_rate': round(occupancy_rate, 1),
        'lower_occupancy': round(lower_occupancy, 1),
        'upper_occupancy': round(upper_occupancy, 1),
    }
    return render(request, 'coordinator/trip_detail.html', context)


@login_required
@coordinator_required
def bus_detail(request, bus_id):
    """
    Centro operacional / ficha técnica de un bus.
    Reúne identidad, KPIs, mantenimiento, combustible, documentos,
    viajes recientes y una línea de tiempo operacional.
    """
    bus = get_object_or_404(
        Bus.objects.select_related('company'),
        pk=bus_id,
    )

    now = timezone.now()
    today = timezone.localdate()

    real_seat_count = Seat.objects.filter(bus=bus).count()

    trips_qs = (
        Trip.objects
        .filter(bus=bus)
        .select_related('route__origin', 'route__destination')
        .annotate(ticket_count=Count('tickets'))
        .order_by('-departure')
    )

    total_trips = trips_qs.count()
    future_trips_count = trips_qs.filter(departure__gt=now).count()
    past_trips_count = trips_qs.filter(departure__lte=now).count()
    total_tickets = Ticket.objects.filter(trip__bus=bus).count()
    total_parcels = Parcel.objects.filter(trip__bus=bus).count()

    upcoming_trips = (
        trips_qs
        .filter(departure__gte=now)
        .order_by('departure')[:5]
    )
    recent_trips = trips_qs[:8]

    documents = BusDocument.objects.filter(bus=bus).order_by('expiry_date')
    documents_count = documents.count()
    expired_documents_count = documents.filter(
        expiry_date__lt=today
    ).count()
    expiring_documents_count = documents.filter(
        expiry_date__gte=today,
        expiry_date__lte=today + timedelta(days=30),
    ).count()

    if expired_documents_count:
        documents_status = 'danger'
        documents_label = f'{expired_documents_count} vencido(s)'
    elif expiring_documents_count:
        documents_status = 'warning'
        documents_label = f'{expiring_documents_count} por vencer'
    else:
        documents_status = 'success'
        documents_label = 'Al día'

    maintenances = (
        Maintenance.objects
        .filter(bus=bus)
        .order_by('-date', '-created_at')
    )
    latest_maintenance = maintenances.first()
    recent_maintenances = maintenances[:5]

    current_km = bus.current_mileage or 0
    next_maintenance_km = bus.next_maintenance_mileage or 0
    maintenance_remaining_km = None
    maintenance_status = 'secondary'
    maintenance_label = 'Sin programación'

    if next_maintenance_km:
        maintenance_remaining_km = next_maintenance_km - current_km
        if maintenance_remaining_km <= 0:
            maintenance_status = 'danger'
            maintenance_label = 'Vencida'
        elif maintenance_remaining_km <= 1000:
            maintenance_status = 'warning'
            maintenance_label = f'{maintenance_remaining_km:,} km restantes'
        else:
            maintenance_status = 'success'
            maintenance_label = f'{maintenance_remaining_km:,} km restantes'

    fuel_qs = FuelRecord.objects.filter(bus=bus).order_by('-date', '-created_at')
    recent_fuel = fuel_qs[:5]
    fuel_totals = fuel_qs.aggregate(
        total_liters=Sum('liters'),
        total_cost=Sum('cost'),
    )

    total_liters = fuel_totals['total_liters'] or 0
    total_fuel_cost = fuel_totals['total_cost'] or 0

    fuel_stats = FuelRecord.get_consumption_stats(bus)
    consumption_per_100km = fuel_stats.get('consumption_per_100km', 0) or 0

    booking_seat_count = Seat.objects.filter(
        bus=bus,
        booking_order_items__isnull=False,
    ).distinct().count()

    seatmap_locked = bool(
        future_trips_count
        or total_tickets
        or booking_seat_count
    )

    timeline = []

    for item in recent_maintenances:
        timeline.append({
            'date': item.date,
            'icon': 'fa-screwdriver-wrench',
            'color': 'warning',
            'title': 'Mantención',
            'text': item.description or item.get_maintenance_type_display(),
            'meta': f'{item.mileage:,} km',
        })

    for item in recent_fuel:
        timeline.append({
            'date': item.date,
            'icon': 'fa-gas-pump',
            'color': 'success',
            'title': 'Carga de combustible',
            'text': f'{item.liters} L',
            'meta': f'${item.cost:,.0f}',
        })

    for item in documents[:5]:
        timeline.append({
            'date': item.expiry_date,
            'icon': 'fa-file-lines',
            'color': (
                'danger'
                if item.expiry_date < today
                else 'warning'
                if item.expiry_date <= today + timedelta(days=30)
                else 'primary'
            ),
            'title': item.get_doc_type_display(),
            'text': 'Vencimiento documental',
            'meta': item.expiry_date.strftime('%d/%m/%Y'),
        })

    for trip in recent_trips[:5]:
        local_departure = timezone.localtime(trip.departure)
        timeline.append({
            'date': local_departure.date(),
            'icon': 'fa-route',
            'color': 'primary',
            'title': 'Viaje',
            'text': f'{trip.route.origin.name} → {trip.route.destination.name}',
            'meta': local_departure.strftime('%d/%m/%Y %H:%M'),
        })

    timeline.sort(
        key=lambda x: x['date'] or today,
        reverse=True,
    )
    timeline = timeline[:12]

    context = {
        'bus': bus,
        'real_seat_count': real_seat_count,
        'total_trips': total_trips,
        'future_trips_count': future_trips_count,
        'past_trips_count': past_trips_count,
        'total_tickets': total_tickets,
        'total_parcels': total_parcels,
        'upcoming_trips': upcoming_trips,
        'recent_trips': recent_trips,
        'documents': documents,
        'documents_count': documents_count,
        'documents_status': documents_status,
        'documents_label': documents_label,
        'expired_documents_count': expired_documents_count,
        'expiring_documents_count': expiring_documents_count,
        'latest_maintenance': latest_maintenance,
        'recent_maintenances': recent_maintenances,
        'maintenance_remaining_km': maintenance_remaining_km,
        'maintenance_status': maintenance_status,
        'maintenance_label': maintenance_label,
        'recent_fuel': recent_fuel,
        'total_liters': total_liters,
        'total_fuel_cost': total_fuel_cost,
        'consumption_per_100km': consumption_per_100km,
        'booking_seat_count': booking_seat_count,
        'seatmap_locked': seatmap_locked,
        'today': today,
        'limit_30_days': today + timedelta(days=30),
        'timeline': timeline,
    }

    return render(
        request,
        'coordinator/bus_detail.html',
        context,
    )

# ============================================================================
# REPORTE DE OCUPACIÓN
# ============================================================================

@login_required
@coordinator_required
def occupancy_report(request):
    import calendar
    from datetime import datetime

    month = request.GET.get('month', datetime.now().strftime('%Y-%m'))
    year, month = map(int, month.split('-'))
    start_date = datetime(year, month, 1).date()
    end_date = (datetime(year, month + 1, 1) - timedelta(days=1)).date() if month < 12 else datetime(year, 12, 31).date()

    trips = Trip.objects.filter(
        departure__date__range=(start_date, end_date)
    ).select_related('route', 'bus').annotate(
        sold_count=Count('tickets')
    )

    data = []
    for trip in trips:
        sold = trip.sold_count
        data.append({
            'date': trip.departure.strftime('%Y-%m-%d'),
            'route': str(trip.route),
            'bus': trip.bus.plate,
            'total': trip.seats_total,
            'sold': sold,
            'occupancy': round(sold / trip.seats_total * 100, 1) if trip.seats_total else 0,
        })

    context = {'data': data, 'month': f"{year}-{month:02d}"}
    return render(request, 'coordinator/occupancy_report.html', context)


# ============================================================================
# CHECK‑IN DE PASAJEROS
# ============================================================================

@login_required
@coordinator_required
@require_http_methods(["GET", "POST"])
def checkin_ticket(request, ticket_number):
    """
    FASE 2E.1 - Check-in seguro de pasajeros.

    GET:
        Muestra y valida el pasaje.
        NO modifica el Ticket.

    POST:
        Confirma embarque.
        Usa SELECT FOR UPDATE para evitar doble check-in concurrente.
    """

    ticket = get_object_or_404(
        Ticket.objects.select_related(
            "trip",
            "trip__route",
            "trip__route__origin",
            "trip__route__destination",
            "seat",
            "customer",
        ),
        number=ticket_number,
    )

    now = timezone.now()

    # ============================================================
    # 1. ESTADO TEMPORAL DEL VIAJE
    # ============================================================

    trip_departure = ticket.trip.departure

    trip_departed = trip_departure < now

    too_early = (
        trip_departure > now + timedelta(minutes=30)
    )

    # ============================================================
    # 2. GET = SOLO MOSTRAR / VALIDAR
    # ============================================================

    if request.method == "GET":

        context = {
            "ticket": ticket,
            "trip": ticket.trip,
            "trip_departed": trip_departed,
            "too_early": too_early,
            "already_checked_in": ticket.checked_in,
        }

        return render(
            request,
            "coordinator/checkin_result.html",
            context,
        )

    # ============================================================
    # 3. POST = CONFIRMAR EMBARQUE
    # ============================================================

    try:

        with transaction.atomic():

            locked_ticket = (
                Ticket.objects
                .select_for_update()
                .select_related(
                    "trip",
                    "trip__route",
                    "trip__route__origin",
                    "trip__route__destination",
                    "seat",
                )
                .get(
                    pk=ticket.pk
                )
            )

            now = timezone.now()

            # ----------------------------------------------------
            # Viaje ya partió
            # ----------------------------------------------------

            if locked_ticket.trip.departure < now:

                messages.error(
                    request,
                    (
                        f"El viaje del ticket "
                        f"{locked_ticket.number} ya partió."
                    ),
                )

                return redirect(
                    "coordinator:checkin",
                    ticket_number=locked_ticket.number,
                )

            # ----------------------------------------------------
            # Ya embarcado
            # ----------------------------------------------------

            if locked_ticket.checked_in:

                messages.warning(
                    request,
                    (
                        f"El pasajero {locked_ticket.buyer_name} "
                        f"ya había sido embarcado."
                    ),
                )

                return redirect(
                    "coordinator:checkin",
                    ticket_number=locked_ticket.number,
                )

            # ----------------------------------------------------
            # Embarcar
            # ----------------------------------------------------

            locked_ticket.checked_in = True
            locked_ticket.checked_in_at = now

            locked_ticket.save(
                update_fields=[
                    "checked_in",
                    "checked_in_at",
                ]
            )

            # ----------------------------------------------------
            # Auditoría
            # ----------------------------------------------------

            AuditLog.objects.create(
                user=request.user,
                action="checkin",
                model_name="Ticket",
                object_id=str(
                    locked_ticket.id
                ),
                object_repr=(
                    f"Check-in: "
                    f"{locked_ticket.number} - "
                    f"{locked_ticket.buyer_name}"
                ),
                ip_address=request.META.get(
                    "REMOTE_ADDR"
                ),
                user_agent=request.META.get(
                    "HTTP_USER_AGENT",
                    "",
                ),
            )

        messages.success(
            request,
            (
                f"Pasajero "
                f"{locked_ticket.buyer_name} "
                f"(asiento "
                f"{locked_ticket.seat.number}) "
                f"embarcado correctamente."
            ),
        )

        return redirect(
            "coordinator:checkin",
            ticket_number=locked_ticket.number,
        )

    except Ticket.DoesNotExist:

        messages.error(
            request,
            "El pasaje ya no existe.",
        )

        return redirect(
            "coordinator:trips_dashboard"
        )

    except Exception:

        logger.exception(
            "Error realizando check-in ticket=%s",
            ticket_number,
        )

        messages.error(
            request,
            "No fue posible confirmar el embarque.",
        )

        return redirect(
            "coordinator:checkin",
            ticket_number=ticket_number,
        )


@login_required
@coordinator_required
@require_http_methods(["GET", "POST"])
def checkin_qr_scan(request):
    """
    FASE 2E.2 - Escaneo y validación de QR firmado.

    GET:
        Muestra la cámara / lector.

    POST:
        Recibe el contenido del QR.
        Valida firma Django.
        Verifica ticket_id + ticket_number.
        Redirige al check-in seguro.
    """
    from django.core import signing
    from django.core.signing import BadSignature

    if request.method == "GET":
        return render(
            request,
            "coordinator/checkin_qr_scan.html",
        )

    qr_value = (
        request.POST.get("qr_value", "")
        .strip()
    )

    if not qr_value:
        messages.error(
            request,
            "No se recibió ningún código QR.",
        )

        return redirect(
            "coordinator:checkin_qr_scan"
        )

    prefix = "CEJER:TICKET:"

    if not qr_value.startswith(prefix):
        messages.error(
            request,
            "El código QR no corresponde a un pasaje Cejer válido.",
        )

        return redirect(
            "coordinator:checkin_qr_scan"
        )

    signed_token = qr_value[len(prefix):]

    try:
        payload = signing.loads(
            signed_token,
            salt="cejer-ticket-qr-v1",
        )

    except BadSignature:
        messages.error(
            request,
            "El código QR es inválido o fue alterado.",
        )

        return redirect(
            "coordinator:checkin_qr_scan"
        )

    except Exception:
        messages.error(
            request,
            "No fue posible validar el código QR.",
        )

        return redirect(
            "coordinator:checkin_qr_scan"
        )

    ticket_id = payload.get("ticket_id")
    ticket_number = payload.get("ticket_number")

    if not ticket_id or not ticket_number:
        messages.error(
            request,
            "El código QR no contiene información válida.",
        )

        return redirect(
            "coordinator:checkin_qr_scan"
        )

    ticket = (
        Ticket.objects
        .filter(
            pk=ticket_id,
            number=ticket_number,
        )
        .first()
    )

    if not ticket:
        messages.error(
            request,
            "El pasaje indicado por el QR no existe.",
        )

        return redirect(
            "coordinator:checkin_qr_scan"
        )

    return redirect(
        "coordinator:checkin",
        ticket_number=ticket.number,
    )


# ============================================================================
# ENCOMIENDAS
# ============================================================================

@login_required
@coordinator_required
def parcel_list(request):
    status_filter = request.GET.get('status', '')
    trip_filter = request.GET.get('trip', '')
    parcels = Parcel.objects.select_related('trip', 'created_by').order_by('-created_at')
    if status_filter:
        parcels = parcels.filter(status=status_filter)
    if trip_filter:
        parcels = parcels.filter(trip_id=trip_filter)
    trips = Trip.objects.all().order_by('departure')
    context = {
        'parcels': parcels,
        'status_filter': status_filter,
        'trip_filter': trip_filter,
        'trips': trips,
    }
    return render(request, 'coordinator/parcel_list.html', context)


@require_POST
@login_required
@coordinator_required
def parcel_deliver(request, parcel_id):
    parcel = get_object_or_404(Parcel, pk=parcel_id)
    if parcel.status == 'pending':
        parcel.deliver()
        messages.success(request, f'Encomienda {parcel.tracking_number} marcada como entregada.')
    else:
        messages.warning(request, 'La encomienda ya no está pendiente.')
    return redirect('coordinator:parcel_list')


# ============================================================================
# MANTENIMIENTO Y COMBUSTIBLE
# ============================================================================

@login_required
@coordinator_required
def maintenance_list(request):
    bus_id = request.GET.get('bus')
    maint_type = request.GET.get('type')
    maintenances = Maintenance.objects.select_related('bus', 'created_by').order_by('-date')
    if bus_id:
        maintenances = maintenances.filter(bus_id=bus_id)
    if maint_type:
        maintenances = maintenances.filter(maintenance_type=maint_type)
    buses = Bus.objects.filter(is_active=True)
    context = {
        'maintenances': maintenances,
        'buses': buses,
        'bus_filter': bus_id,
        'type_filter': maint_type,
    }
    return render(request, 'coordinator/maintenance_list.html', context)


@login_required
@coordinator_required
def maintenance_create(request, bus_id=None):
    """
    Registra una mantención usando los campos reales del modelo Maintenance
    y sincroniza los datos operacionales principales del bus.
    """
    bus = None
    if bus_id:
        bus = get_object_or_404(Bus, pk=bus_id)

    if request.method == 'POST':
        try:
            bus_post_id = request.POST.get('bus')
            if not bus_post_id:
                raise ValidationError("Debe seleccionar un bus.")

            maintenance_bus = get_object_or_404(Bus, pk=bus_post_id)

            mileage_raw = request.POST.get('mileage')
            if mileage_raw in (None, ''):
                raise ValidationError("Debe ingresar el kilometraje de la mantención.")

            mileage = int(mileage_raw)
            if mileage < 0:
                raise ValidationError("El kilometraje no puede ser negativo.")

            # Compatibilidad con el template actual:
            # acepta next_due y también next_maintenance_km.
            next_km_raw = (
                request.POST.get('next_maintenance_km')
                or request.POST.get('next_due')
                or 0
            )
            next_maintenance_km = int(next_km_raw)

            cost_raw = request.POST.get('cost') or '0'
            cost = Decimal(cost_raw)

            with transaction.atomic():
                maintenance = Maintenance.objects.create(
                    bus=maintenance_bus,
                    maintenance_type=request.POST.get('maintenance_type'),
                    date=request.POST.get('date'),
                    mileage=mileage,
                    description=request.POST.get('description', ''),
                    cost=cost,
                    workshop=request.POST.get('workshop', ''),
                    next_maintenance_km=next_maintenance_km,
                    technician=request.POST.get('technician', ''),
                    notes=request.POST.get('notes', ''),
                    created_by=request.user,
                )

                # Sincronizar el kilometraje actual sólo si el registro
                # informa un valor superior al que ya tiene el bus.
                update_fields = []

                if mileage > (maintenance_bus.current_mileage or 0):
                    maintenance_bus.current_mileage = mileage
                    update_fields.append('current_mileage')

                # La mantención más reciente define los datos resumidos del bus.
                latest = (
                    Maintenance.objects
                    .filter(bus=maintenance_bus)
                    .order_by('-date', '-created_at')
                    .first()
                )

                if latest and latest.pk == maintenance.pk:
                    maintenance_bus.last_maintenance = maintenance.date
                    maintenance_bus.last_maintenance_mileage = maintenance.mileage
                    maintenance_bus.next_maintenance_mileage = maintenance.next_maintenance_km
                    update_fields.extend([
                        'last_maintenance',
                        'last_maintenance_mileage',
                        'next_maintenance_mileage',
                    ])

                if update_fields:
                    maintenance_bus.save(
                        update_fields=list(dict.fromkeys(update_fields))
                    )

            messages.success(
                request,
                f'Mantenimiento registrado para {maintenance.bus.plate}.'
            )
            return redirect('coordinator:maintenance_list')

        except (ValueError, TypeError):
            messages.error(
                request,
                'Kilometraje, próximo mantenimiento o costo tienen un formato inválido.'
            )
        except ValidationError as e:
            messages.error(request, str(e))
        except Exception as e:
            messages.error(request, f'Error: {str(e)}')

    buses = Bus.objects.filter(is_active=True).order_by('plate')
    context = {
        'buses': buses,
        'selected_bus': bus,
    }
    return render(
        request,
        'coordinator/maintenance_form.html',
        context,
    )


@login_required
@coordinator_required
def maintenance_edit(request, pk):
    """
    Edita una mantención y vuelve a sincronizar el resumen de mantenimiento
    del bus con el registro más reciente.
    """
    maintenance = get_object_or_404(
        Maintenance.objects.select_related('bus'),
        pk=pk,
    )

    if request.method == 'POST':
        try:
            bus_post_id = request.POST.get('bus')
            if not bus_post_id:
                raise ValidationError("Debe seleccionar un bus.")

            old_bus = maintenance.bus
            maintenance_bus = get_object_or_404(Bus, pk=bus_post_id)

            mileage_raw = request.POST.get('mileage')
            if mileage_raw in (None, ''):
                raise ValidationError("Debe ingresar el kilometraje de la mantención.")

            mileage = int(mileage_raw)
            if mileage < 0:
                raise ValidationError("El kilometraje no puede ser negativo.")

            next_km_raw = (
                request.POST.get('next_maintenance_km')
                or request.POST.get('next_due')
                or 0
            )
            next_maintenance_km = int(next_km_raw)

            cost = Decimal(request.POST.get('cost') or '0')

            with transaction.atomic():
                maintenance.bus = maintenance_bus
                maintenance.maintenance_type = request.POST.get('maintenance_type')
                maintenance.date = request.POST.get('date')
                maintenance.mileage = mileage
                maintenance.description = request.POST.get('description', '')
                maintenance.cost = cost
                maintenance.workshop = request.POST.get('workshop', '')
                maintenance.next_maintenance_km = next_maintenance_km
                maintenance.technician = request.POST.get('technician', '')
                maintenance.notes = request.POST.get('notes', '')
                maintenance.save()

                # Si cambió de bus, recalcular también el bus anterior.
                buses_to_sync = {old_bus.pk: old_bus, maintenance_bus.pk: maintenance_bus}

                for bus_obj in buses_to_sync.values():
                    latest = (
                        Maintenance.objects
                        .filter(bus=bus_obj)
                        .order_by('-date', '-created_at')
                        .first()
                    )

                    if latest:
                        bus_obj.last_maintenance = latest.date
                        bus_obj.last_maintenance_mileage = latest.mileage
                        bus_obj.next_maintenance_mileage = latest.next_maintenance_km

                        if latest.mileage > (bus_obj.current_mileage or 0):
                            bus_obj.current_mileage = latest.mileage

                        bus_obj.save(update_fields=[
                            'last_maintenance',
                            'last_maintenance_mileage',
                            'next_maintenance_mileage',
                            'current_mileage',
                        ])
                    else:
                        bus_obj.last_maintenance = None
                        bus_obj.last_maintenance_mileage = 0
                        bus_obj.next_maintenance_mileage = 0
                        bus_obj.save(update_fields=[
                            'last_maintenance',
                            'last_maintenance_mileage',
                            'next_maintenance_mileage',
                        ])

            messages.success(request, 'Mantenimiento actualizado.')
            return redirect('coordinator:maintenance_list')

        except (ValueError, TypeError):
            messages.error(
                request,
                'Kilometraje, próximo mantenimiento o costo tienen un formato inválido.'
            )
        except ValidationError as e:
            messages.error(request, str(e))
        except Exception as e:
            messages.error(request, f'Error: {str(e)}')

    buses = Bus.objects.filter(is_active=True).order_by('plate')
    context = {
        'maintenance': maintenance,
        'buses': buses,
    }
    return render(
        request,
        'coordinator/maintenance_form.html',
        context,
    )


@login_required
@coordinator_required
def maintenance_delete(request, pk):
    maintenance = get_object_or_404(Maintenance, pk=pk)
    maintenance.delete()
    messages.success(request, 'Mantenimiento eliminado.')
    return redirect('coordinator:maintenance_list')


@login_required
@coordinator_required
def fuel_list(request):
    """
    Lista las cargas de combustible y calcula rendimiento sólo cuando
    existen dos cargas cronológicamente consecutivas del mismo bus
    con kilometraje creciente.
    """
    bus_id = request.GET.get('bus')

    qs = FuelRecord.objects.select_related('bus', 'created_by')
    if bus_id:
        qs = qs.filter(bus_id=bus_id)

    records_asc = list(
        qs.order_by('bus_id', 'date', 'created_at', 'id')
    )

    previous_by_bus = {}
    efficiencies = []
    total_liters = Decimal('0')
    total_cost = Decimal('0')

    for record in records_asc:
        record.distance_since_previous = None
        record.efficiency_kml = None
        record.cost_per_km = None

        liters = record.liters or Decimal('0')
        cost = record.cost or Decimal('0')

        total_liters += liters
        total_cost += cost

        previous = previous_by_bus.get(record.bus_id)

        if previous:
            distance = record.mileage - previous.mileage

            # Nunca calcular con un retroceso o kilometraje repetido.
            if distance > 0 and liters > 0:
                record.distance_since_previous = distance
                record.efficiency_kml = round(
                    Decimal(distance) / liters,
                    2,
                )
                record.cost_per_km = round(
                    cost / Decimal(distance),
                    2,
                )
                efficiencies.append(record.efficiency_kml)

        previous_by_bus[record.bus_id] = record

    # Mostrar lo más reciente primero.
    records = sorted(
        records_asc,
        key=lambda r: (r.date, r.created_at, r.id),
        reverse=True,
    )

    avg_efficiency = (
        round(
            sum(efficiencies, Decimal('0')) / Decimal(len(efficiencies)),
            2,
        )
        if efficiencies else None
    )

    buses = Bus.objects.filter(is_active=True).order_by('plate')

    return render(
        request,
        'coordinator/fuel_list.html',
        {
            'records': records,
            'buses': buses,
            'bus_filter': bus_id,
            'total_liters': total_liters,
            'total_cost': total_cost,
            'avg_efficiency': avg_efficiency,
            'records_count': len(records),
        },
    )

@login_required
@coordinator_required
def fuel_create(request, bus_id=None):
    """
    Registra una carga de combustible protegiendo la integridad
    del kilometraje del bus.
    """
    selected_bus = None
    if bus_id:
        selected_bus = get_object_or_404(
            Bus,
            pk=bus_id,
            is_active=True,
        )

    if request.method == 'POST':
        try:
            bus_id = request.POST.get('bus')
            if not bus_id:
                raise ValidationError("Debe seleccionar un bus.")

            liters_raw = request.POST.get('liters')
            cost_raw = request.POST.get('cost')
            mileage_raw = request.POST.get('mileage')
            date_raw = request.POST.get('date')

            if not date_raw:
                raise ValidationError("Debe ingresar la fecha.")
            if liters_raw in (None, ''):
                raise ValidationError("Debe ingresar los litros cargados.")
            if cost_raw in (None, ''):
                raise ValidationError("Debe ingresar el costo de la carga.")
            if mileage_raw in (None, ''):
                raise ValidationError("Debe ingresar el kilometraje actual.")

            liters = Decimal(liters_raw)
            cost = Decimal(cost_raw)
            mileage = int(mileage_raw)

            if liters <= 0:
                raise ValidationError("Los litros deben ser mayores que 0.")
            if cost < 0:
                raise ValidationError("El costo no puede ser negativo.")
            if mileage < 0:
                raise ValidationError("El kilometraje no puede ser negativo.")

            with transaction.atomic():
                bus = get_object_or_404(
                    Bus.objects.select_for_update(),
                    pk=bus_id,
                )

                # Tomamos como piso el MAYOR kilometraje conocido del bus,
                # no sólo current_mileage. Esto recupera protección incluso
                # si un registro antiguo ya bajó current_mileage por error.
                fuel_max = (
                    FuelRecord.objects
                    .filter(bus=bus)
                    .aggregate(max_km=Max('mileage'))
                    .get('max_km')
                    or 0
                )

                maintenance_max = (
                    Maintenance.objects
                    .filter(bus=bus)
                    .aggregate(max_km=Max('mileage'))
                    .get('max_km')
                    or 0
                )

                minimum_allowed = max(
                    bus.current_mileage or 0,
                    bus.last_maintenance_mileage or 0,
                    fuel_max,
                    maintenance_max,
                )

                if mileage < minimum_allowed:
                    raise ValidationError(
                        f"Kilometraje inválido. El mayor kilometraje conocido "
                        f"del bus {bus.plate} es {minimum_allowed:,} km. "
                        "La nueva carga no puede registrar un valor inferior."
                    )

                record = FuelRecord.objects.create(
                    bus=bus,
                    date=date_raw,
                    liters=liters,
                    cost=cost,
                    mileage=mileage,
                    created_by=request.user,
                )

                # Sincronizar siempre hacia arriba, nunca hacia abajo.
                if mileage > (bus.current_mileage or 0):
                    bus.current_mileage = mileage
                    bus.save(update_fields=['current_mileage'])

            messages.success(
                request,
                f'Carga de combustible registrada para {record.bus.plate}.'
            )
            return redirect('coordinator:fuel_list')

        except ValidationError as e:
            messages.error(request, str(e))
        except (ValueError, TypeError):
            messages.error(
                request,
                'Litros, costo o kilometraje tienen un formato inválido.'
            )
        except Exception as e:
            messages.error(request, f'Error: {str(e)}')

    buses = Bus.objects.filter(is_active=True).order_by('plate')
    return render(
        request,
        'coordinator/fuel_form.html',
        {
            'buses': buses,
            'selected_bus': selected_bus,
        },
    )

@login_required
@coordinator_required
def fuel_delete(request, pk):
    """
    Elimina un registro de combustible y vuelve a dejar el kilometraje
    operacional del bus al menos en el mayor kilometraje histórico conocido.
    """
    record = get_object_or_404(
        FuelRecord.objects.select_related('bus'),
        pk=pk,
    )

    with transaction.atomic():
        bus = Bus.objects.select_for_update().get(pk=record.bus_id)
        record.delete()

        fuel_max = (
            FuelRecord.objects
            .filter(bus=bus)
            .aggregate(max_km=Max('mileage'))
            .get('max_km')
            or 0
        )

        maintenance_max = (
            Maintenance.objects
            .filter(bus=bus)
            .aggregate(max_km=Max('mileage'))
            .get('max_km')
            or 0
        )

        highest_known = max(
            bus.current_mileage or 0,
            bus.last_maintenance_mileage or 0,
            fuel_max,
            maintenance_max,
        )

        if highest_known != (bus.current_mileage or 0):
            bus.current_mileage = highest_known
            bus.save(update_fields=['current_mileage'])

    messages.success(request, 'Registro de combustible eliminado.')
    return redirect('coordinator:fuel_list')

@login_required
@coordinator_required
def bus_maintenance_history(request, bus_id):
    bus = get_object_or_404(Bus, pk=bus_id)
    maintenances = Maintenance.objects.filter(bus=bus).order_by('-date')
    context = {
        'bus': bus,
        'maintenances': maintenances,
    }
    return render(request, 'coordinator/bus_maintenance_history.html', context)


# ============================================================================
# MÓDULO DE SEGURIDAD Y LEY 21.719
# ============================================================================

@login_required
@coordinator_required
def seguridad_dashboard(request):
    """Panel principal de seguridad con estadísticas y resumen."""
    total_logs = AuditLog.objects.count()
    login_failed = AuditLog.objects.filter(action='login_failed').count()
    recent_logs = AuditLog.objects.all()[:10]
    
    today = timezone.now().date()
    usuarios_activos = AuditLog.objects.filter(
        action='login',
        timestamp__date=today
    ).values_list('user_id', flat=True).distinct().count()
    
    context = {
        'title': 'Ley 21.719 - Seguridad y Protección de Datos',
        'total_logs': total_logs,
        'login_failed': login_failed,
        'usuarios_activos': usuarios_activos,
        'recent_logs': recent_logs,
    }
    return render(request, 'coordinator/seguridad/dashboard.html', context)


@login_required
@coordinator_required
def seguridad_auditoria(request):
    """Lista de logs de auditoría con filtros."""
    query = request.GET.get('q', '')
    action_filter = request.GET.get('action', '')
    date_from = request.GET.get('date_from', '')
    date_to = request.GET.get('date_to', '')
    
    logs = AuditLog.objects.select_related('user').all()
    
    if query:
        logs = logs.filter(
            Q(user__username__icontains=query) |
            Q(object_repr__icontains=query) |
            Q(model_name__icontains=query)
        )
    if action_filter:
        logs = logs.filter(action=action_filter)
    if date_from:
        logs = logs.filter(timestamp__date__gte=date_from)
    if date_to:
        logs = logs.filter(timestamp__date__lte=date_to)
    
    paginator = Paginator(logs, 50)
    page = request.GET.get('page')
    logs_page = paginator.get_page(page)
    
    context = {
        'title': 'Auditoría - Ley 21.719',
        'logs': logs_page,
        'action_choices': AuditLog.ACTION_CHOICES,
        'query': query,
        'action_filter': action_filter,
        'date_from': date_from,
        'date_to': date_to,
    }
    return render(request, 'coordinator/seguridad/auditoria.html', context)


@login_required
@coordinator_required
def seguridad_respaldos(request):
    """Gestión de respaldos de la base de datos."""
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'download_backup':
            backup_file = create_backup()
            if backup_file:
                AuditLog.objects.create(
                    user=request.user,
                    action='download_backup',
                    ip_address=request.META.get('REMOTE_ADDR'),
                    user_agent=request.META.get('HTTP_USER_AGENT', ''),
                )
                return FileResponse(
                    open(backup_file, 'rb'),
                    as_attachment=True,
                    filename=os.path.basename(backup_file)
                )
            else:
                messages.error(request, 'Error al generar el respaldo.')
        elif action == 'create_backup':
            backup_file = create_backup()
            if backup_file:
                AuditLog.objects.create(
                    user=request.user,
                    action='backup_created',
                    ip_address=request.META.get('REMOTE_ADDR'),
                    user_agent=request.META.get('HTTP_USER_AGENT', ''),
                )
                messages.success(request, f'Respaldo creado: {os.path.basename(backup_file)}')
            else:
                messages.error(request, 'Error al crear el respaldo.')
    
    backup_dir = get_backup_dir()
    backups = []
    if os.path.exists(backup_dir):
        for f in sorted(os.listdir(backup_dir), reverse=True):
            if f.endswith('.sql') or f.endswith('.dump'):
                path = os.path.join(backup_dir, f)
                backups.append({
                    'name': f,
                    'size': os.path.getsize(path),
                    'modified': os.path.getmtime(path),
                    'path': path
                })
    
    context = {
        'title': 'Respaldos - Ley 21.719',
        'backups': backups[:10],
    }
    return render(request, 'coordinator/seguridad/respaldos.html', context)


@login_required
@coordinator_required
def seguridad_incidentes(request):
    """Registro de incidentes de seguridad (intentos fallidos, accesos sospechosos)."""
    logs = AuditLog.objects.filter(
        Q(action='login_failed')
    ).select_related('user').order_by('-timestamp')
    
    paginator = Paginator(logs, 50)
    page = request.GET.get('page')
    logs_page = paginator.get_page(page)
    
    context = {
        'title': 'Incidentes de Seguridad',
        'logs': logs_page,
    }
    return render(request, 'coordinator/seguridad/incidentes.html', context)


@login_required
@coordinator_required
def seguridad_descargar_respaldo(request, filename):
    """Descarga un archivo de respaldo."""
    backup_dir = os.path.join(settings.BASE_DIR, 'backups')
    file_path = os.path.join(backup_dir, filename)
    if os.path.exists(file_path) and os.path.isfile(file_path):
        with open(file_path, 'rb') as f:
            response = HttpResponse(f.read(), content_type='application/octet-stream')
            response['Content-Disposition'] = f'attachment; filename="{filename}"'
            return response
    return JsonResponse({'error': 'Archivo no encontrado'}, status=404)


@login_required
@coordinator_required
@require_POST
def seguridad_eliminar_respaldo(request, filename):
    """Elimina un archivo de respaldo."""
    try:
        backup_dir = os.path.join(settings.BASE_DIR, 'backups')
        file_path = os.path.join(backup_dir, filename)
        if os.path.exists(file_path) and os.path.isfile(file_path):
            os.remove(file_path)
            return JsonResponse({'success': True})
        return JsonResponse({'error': 'Archivo no encontrado'}, status=404)
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=500)


@login_required
@coordinator_required
@require_POST
def seguridad_guardar_programacion(request):
    try:
        data = json.loads(request.body)
        frequency = data.get('frequency', 'daily')
        time = data.get('time', '03:00')
        return JsonResponse({'success': True})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=500)


@login_required
@coordinator_required
@require_POST
def seguridad_resolver_incidente(request, incident_id):
    try:
        return JsonResponse({'success': True})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=500)


@login_required
@coordinator_required
@require_POST
def seguridad_crear_respaldo(request):
    """Crea un respaldo de la base de datos y devuelve JSON."""
    try:
        backup_file = create_backup()
        if backup_file:
            AuditLog.objects.create(
                user=request.user,
                action='backup_created',
                ip_address=request.META.get('REMOTE_ADDR'),
                user_agent=request.META.get('HTTP_USER_AGENT', ''),
                object_repr=f"Respaldo: {os.path.basename(backup_file)}"
            )
            return JsonResponse({'success': True, 'message': 'Respaldo creado correctamente'})
        else:
            return JsonResponse({'success': False, 'error': 'Error al crear el respaldo'}, status=500)
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=500)